"""
Script to add students from the group photo and train face recognition model
"""
import os
import sys
import cv2
import numpy as np
from app import app, db
from models import User, Student, Teacher, Class
from face_recognition_utils import detect_faces, encode_face
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def extract_and_encode_faces_from_group(image_path):
    """Extract individual face encodings from the group photo"""
    try:
        # Read the image
        image = cv2.imread(image_path)
        if image is None:
            logger.error(f"Could not load image from {image_path}")
            return []
        
        # Detect faces in the group photo using the image array directly
        face_locations, processed_image = detect_faces(image)
        
        if not face_locations:
            logger.error("No faces detected in the group photo")
            return []
        
        logger.info(f"Detected {len(face_locations)} faces in the group photo")
        
        # Extract and encode each face
        face_encodings = []
        for i, (top, right, bottom, left) in enumerate(face_locations):
            # Extract face region with padding
            padding = 30
            y_start = max(0, top - padding)
            y_end = min(image.shape[0], bottom + padding)
            x_start = max(0, left - padding)
            x_end = min(image.shape[1], right + padding)
            
            face_region = image[y_start:y_end, x_start:x_end]
            
            if face_region.size == 0:
                logger.warning(f"Empty face region for face {i+1}")
                continue
            
            # Resize face to standard size for better encoding
            face_resized = cv2.resize(face_region, (200, 200))
            
            # Save individual face for verification
            face_filename = f"extracted_face_{i+1}.jpg"
            cv2.imwrite(face_filename, face_resized)
            logger.info(f"Extracted and saved face {i+1} as {face_filename}")
            
            # Create encoding from the extracted face
            encoding = encode_face_from_array(face_resized)
            if encoding is not None:
                face_encodings.append((i, encoding))
                logger.info(f"Successfully encoded face {i+1}")
            else:
                logger.warning(f"Failed to encode face {i+1}")
        
        return face_encodings
    
    except Exception as e:
        logger.error(f"Error extracting faces: {e}")
        return []

def encode_face_from_array(face_array):
    """Create face encoding from face image array"""
    try:
        # Save face image temporarily for encoding
        temp_filename = "temp_face_encoding.jpg"
        cv2.imwrite(temp_filename, face_array)
        
        # Get encoding using the existing function
        encoding = encode_face(temp_filename)
        
        # Clean up temporary file
        if os.path.exists(temp_filename):
            os.remove(temp_filename)
        
        return encoding
        
    except Exception as e:
        logger.error(f"Error encoding face from array: {e}")
        return None

def create_teacher_if_not_exists():
    """Create a teacher if none exists"""
    teacher = Teacher.query.first()
    if not teacher:
        # Create teacher user
        teacher_user = User()
        teacher_user.username = "teacher1"
        teacher_user.email = "teacher@school.edu"
        teacher_user.role = "teacher"
        teacher_user.set_password("password123")
        db.session.add(teacher_user)
        db.session.flush()
        
        # Create teacher profile
        teacher = Teacher()
        teacher.user_id = teacher_user.id
        teacher.first_name = "Dr. Sarah"
        teacher.last_name = "Johnson"
        teacher.subject = "Computer Science"
        db.session.add(teacher)
        db.session.commit()
        logger.info("Created teacher account")
    
    return teacher

def create_class_if_not_exists(teacher_id):
    """Create a class if none exists"""
    class_obj = Class.query.first()
    if not class_obj:
        class_obj = Class()
        class_obj.name = "Computer Science 101"
        class_obj.description = "Introduction to Computer Science and Programming"
        class_obj.teacher_id = teacher_id
        db.session.add(class_obj)
        db.session.commit()
        logger.info("Created Computer Science class")
    
    return class_obj

def add_student_with_face_encoding(username, email, first_name, last_name, roll_number, face_encoding):
    """Add a student with face encoding"""
    try:
        # Check if student already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            logger.info(f"Student {username} already exists, skipping...")
            return None
        
        # Create user account
        user = User()
        user.username = username
        user.email = email
        user.role = "student"
        user.set_password("student123")  # Default password
        db.session.add(user)
        db.session.flush()
        
        # Create student profile
        student = Student()
        student.user_id = user.id
        student.first_name = first_name
        student.last_name = last_name
        student.roll_number = roll_number
        student.face_encoding = face_encoding
        db.session.add(student)
        db.session.commit()
        
        logger.info(f"Added student: {first_name} {last_name} ({username})")
        return student
        
    except Exception as e:
        logger.error(f"Error adding student {username}: {e}")
        db.session.rollback()
        return None

def add_students_to_class(class_obj):
    """Add all students to the class"""
    students = Student.query.all()
    for student in students:
        if student not in class_obj.students:
            class_obj.students.append(student)
    
    db.session.commit()
    logger.info(f"Added {len(students)} students to {class_obj.name}")

def main():
    """Main function to process the group photo and add students"""
    with app.app_context():
        # Path to the group photo
        group_photo_path = "attached_assets/download_1749397125961.jpg"
        
        # Extract face encodings from the group photo
        face_encodings = extract_and_encode_faces_from_group(group_photo_path)
        
        if not face_encodings:
            logger.error("No face encodings could be created from the group photo")
            return
        
        # Create teacher and class if they don't exist
        teacher = create_teacher_if_not_exists()
        class_obj = create_class_if_not_exists(teacher.id)
        
        # Student data - based on the positions in the photo (left to right)
        student_data = [
            ("alex_chen", "alex.chen@student.edu", "Alex", "Chen", "CS001"),
            ("maria_garcia", "maria.garcia@student.edu", "Maria", "Garcia", "CS002"),
            ("james_smith", "james.smith@student.edu", "James", "Smith", "CS003"),
            ("emma_johnson", "emma.johnson@student.edu", "Emma", "Johnson", "CS004"),
            ("sophia_williams", "sophia.williams@student.edu", "Sophia", "Williams", "CS005")
        ]
        
        # Add each student with their corresponding face encoding
        added_students = 0
        for face_index, face_encoding in face_encodings:
            if face_index < len(student_data):
                username, email, first_name, last_name, roll_number = student_data[face_index]
                student = add_student_with_face_encoding(
                    username, email, first_name, last_name, roll_number, face_encoding
                )
                
                if student:
                    added_students += 1
                    logger.info(f"Successfully added student {first_name} {last_name}")
                else:
                    logger.error(f"Failed to add student {first_name} {last_name}")
        
        # Add all students to the class
        add_students_to_class(class_obj)
        
        logger.info(f"Face recognition model training complete! Added {added_students} students.")
        logger.info("Students can now log in with their username and password 'student123'")
        logger.info("Teacher can log in with username 'teacher1' and password 'password123'")

if __name__ == "__main__":
    main()