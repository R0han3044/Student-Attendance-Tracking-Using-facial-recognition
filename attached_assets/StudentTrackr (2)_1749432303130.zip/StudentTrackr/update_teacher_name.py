"""
Script to update the name of a teacher in the database
"""
import logging
from app import app, db
from models import User, Teacher

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def update_teacher_name(username, new_first_name, new_last_name):
    """Update the first and last name of a teacher with the given username"""
    with app.app_context():
        # Find the user with the given username and role 'teacher'
        user = User.query.filter_by(username=username, role='teacher').first()
        
        if not user:
            logger.error(f"No teacher found with username: {username}")
            return False
        
        # Get the teacher profile for this user
        teacher = Teacher.query.filter_by(user_id=user.id).first()
        
        if not teacher:
            logger.error(f"No teacher profile found for user with username: {username}")
            return False
        
        # Update teacher names
        old_first_name = teacher.first_name
        old_last_name = teacher.last_name
        teacher.first_name = new_first_name
        teacher.last_name = new_last_name
        
        # Commit the changes
        db.session.commit()
        
        logger.info(f"Updated teacher name from '{old_first_name} {old_last_name}' to '{new_first_name} {new_last_name}'")
        return True

if __name__ == "__main__":
    # Update teacher1's name to Vijay Kumar
    username = "teacher1"
    new_first_name = "Vijay"
    new_last_name = "Kumar"
    
    success = update_teacher_name(username, new_first_name, new_last_name)
    
    if success:
        print(f"Successfully updated {username}'s name to {new_first_name} {new_last_name}")
    else:
        print(f"Failed to update {username}'s name")