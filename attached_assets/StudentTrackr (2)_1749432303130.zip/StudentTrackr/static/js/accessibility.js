/**
 * Accessibility JavaScript for the Face Recognition Attendance System
 * This script provides functionality to enhance the user experience for 
 * individuals with visual impairments including color blindness
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get all control buttons
    const fontIncreaseBtn = document.getElementById('font-size-increase');
    const fontDecreaseBtn = document.getElementById('font-size-decrease');
    const highContrastBtn = document.getElementById('high-contrast-toggle');
    const colorBlindBtn = document.getElementById('color-blind-toggle');
    
    // Load user preferences from localStorage
    loadAccessibilitySettings();
    
    // Set up event listeners for accessibility controls
    if (fontIncreaseBtn) {
        fontIncreaseBtn.addEventListener('click', function() {
            increaseFontSize();
        });
    }
    
    if (fontDecreaseBtn) {
        fontDecreaseBtn.addEventListener('click', function() {
            decreaseFontSize();
        });
    }
    
    if (highContrastBtn) {
        highContrastBtn.addEventListener('click', function() {
            toggleHighContrast();
        });
    }
    
    if (colorBlindBtn) {
        colorBlindBtn.addEventListener('click', function() {
            toggleColorBlindMode();
        });
    }
    
    // Add global focus outline for keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('is-keyboard-user');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('is-keyboard-user');
    });
    
    // Add labels to status indicators for screen readers
    addAccessibleLabels();
});

/**
 * Load user's accessibility preferences from localStorage
 */
function loadAccessibilitySettings() {
    // Font size
    const fontSize = localStorage.getItem('accessibility-font-size');
    if (fontSize === 'larger') {
        document.body.classList.add('larger-text');
        document.body.classList.remove('xl-text');
    } else if (fontSize === 'xl') {
        document.body.classList.add('xl-text');
        document.body.classList.remove('larger-text');
    }
    
    // High contrast
    const highContrast = localStorage.getItem('accessibility-high-contrast');
    if (highContrast === 'enabled') {
        document.body.classList.add('high-contrast');
    }
    
    // Color blind friendly
    const colorBlind = localStorage.getItem('accessibility-color-blind');
    if (colorBlind === 'enabled') {
        document.body.classList.add('color-blind-friendly');
    }
}

/**
 * Increase font size
 */
function increaseFontSize() {
    if (document.body.classList.contains('xl-text')) {
        // Already at max size
        return;
    } else if (document.body.classList.contains('larger-text')) {
        document.body.classList.remove('larger-text');
        document.body.classList.add('xl-text');
        localStorage.setItem('accessibility-font-size', 'xl');
    } else {
        document.body.classList.add('larger-text');
        localStorage.setItem('accessibility-font-size', 'larger');
    }
    
    // Announce to screen readers
    announceChange('Font size increased');
}

/**
 * Decrease font size
 */
function decreaseFontSize() {
    if (document.body.classList.contains('xl-text')) {
        document.body.classList.remove('xl-text');
        document.body.classList.add('larger-text');
        localStorage.setItem('accessibility-font-size', 'larger');
    } else if (document.body.classList.contains('larger-text')) {
        document.body.classList.remove('larger-text');
        localStorage.setItem('accessibility-font-size', 'normal');
    }
    
    // Announce to screen readers
    announceChange('Font size decreased');
}

/**
 * Toggle high contrast mode
 */
function toggleHighContrast() {
    if (document.body.classList.contains('high-contrast')) {
        document.body.classList.remove('high-contrast');
        localStorage.setItem('accessibility-high-contrast', 'disabled');
        announceChange('High contrast mode disabled');
    } else {
        document.body.classList.add('high-contrast');
        localStorage.setItem('accessibility-high-contrast', 'enabled');
        announceChange('High contrast mode enabled');
    }
}

/**
 * Toggle color blind friendly mode
 */
function toggleColorBlindMode() {
    if (document.body.classList.contains('color-blind-friendly')) {
        document.body.classList.remove('color-blind-friendly');
        localStorage.setItem('accessibility-color-blind', 'disabled');
        announceChange('Color blind friendly mode disabled');
    } else {
        document.body.classList.add('color-blind-friendly');
        localStorage.setItem('accessibility-color-blind', 'enabled');
        announceChange('Color blind friendly mode enabled');
    }
}

/**
 * Announce changes to screen readers
 */
function announceChange(message) {
    let announcer = document.getElementById('accessibility-announcer');
    
    if (!announcer) {
        announcer = document.createElement('div');
        announcer.id = 'accessibility-announcer';
        announcer.setAttribute('aria-live', 'polite');
        announcer.setAttribute('aria-atomic', 'true');
        announcer.classList.add('sr-only');
        document.body.appendChild(announcer);
    }
    
    announcer.textContent = message;
    
    // Clear the announcer after a delay
    setTimeout(() => {
        announcer.textContent = '';
    }, 3000);
}

/**
 * Add screen reader labels to status indicators
 */
function addAccessibleLabels() {
    // Add descriptions to status badges
    document.querySelectorAll('.badge').forEach(badge => {
        if (!badge.getAttribute('aria-label')) {
            if (badge.classList.contains('bg-success')) {
                badge.setAttribute('aria-label', 'Status: Present');
            } else if (badge.classList.contains('bg-warning')) {
                badge.setAttribute('aria-label', 'Status: Late');
            } else if (badge.classList.contains('bg-danger')) {
                badge.setAttribute('aria-label', 'Status: Absent');
            }
        }
    });
    
    // Add descriptions to chart elements if they exist
    const charts = document.querySelectorAll('canvas.chart');
    if (charts.length > 0) {
        charts.forEach(chart => {
            if (!chart.getAttribute('aria-label')) {
                chart.setAttribute('aria-label', 'Chart showing attendance data');
                chart.setAttribute('role', 'img');
            }
        });
    }
}