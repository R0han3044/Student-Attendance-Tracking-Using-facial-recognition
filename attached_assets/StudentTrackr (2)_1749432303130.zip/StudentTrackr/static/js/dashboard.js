/**
 * Dashboard JavaScript
 * Handles dashboard functionality including charts
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize attendance charts if they exist
    initializeCharts();
    
    // Setup real-time counters if they exist
    setupCounters();
    
    // Initialize any dropdowns
    initializeDropdowns();
    
    // Setup date range picker if it exists
    setupDateRangePicker();
});

/**
 * Initialize attendance charts
 */
function initializeCharts() {
    // Attendance Overview Chart
    const attendanceChartEl = document.getElementById('attendanceChart');
    if (attendanceChartEl) {
        const chartData = JSON.parse(attendanceChartEl.dataset.chart);
        
        new Chart(attendanceChartEl, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: chartData.datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#ccc'
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ccc'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#ccc'
                        },
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Class Attendance Rate Chart
    const rateChartEl = document.getElementById('attendanceRateChart');
    if (rateChartEl) {
        const chartData = JSON.parse(rateChartEl.dataset.chart);
        
        new Chart(rateChartEl, {
            type: 'doughnut',
            data: {
                labels: ['Present', 'Late', 'Absent'],
                datasets: [{
                    data: [
                        chartData.present,
                        chartData.late,
                        chartData.absent
                    ],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(255, 99, 132, 0.8)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: '#ccc'
                        }
                    }
                }
            }
        });
    }
}

/**
 * Setup real-time counters
 */
function setupCounters() {
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const increment = target / 20; // Increment by 5% of the target each step
        
        const updateCounter = () => {
            const current = +counter.innerText;
            if (current < target) {
                counter.innerText = Math.ceil(current + increment);
                setTimeout(updateCounter, 50);
            } else {
                counter.innerText = target;
            }
        };
        
        updateCounter();
    });
}

/**
 * Initialize dropdowns
 */
function initializeDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown-toggle');
    
    dropdowns.forEach(dropdown => {
        dropdown.addEventListener('click', function() {
            const dropdownMenu = this.nextElementSibling;
            if (dropdownMenu.classList.contains('show')) {
                dropdownMenu.classList.remove('show');
            } else {
                // Close all other dropdowns
                document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                    menu.classList.remove('show');
                });
                
                dropdownMenu.classList.add('show');
            }
        });
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.matches('.dropdown-toggle') && !e.target.closest('.dropdown-menu')) {
            document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
                menu.classList.remove('show');
            });
        }
    });
}

/**
 * Setup date range picker
 */
function setupDateRangePicker() {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (startDateInput && endDateInput) {
        // Set min date on end date based on start date
        startDateInput.addEventListener('change', function() {
            endDateInput.min = this.value;
            
            // If end date is before start date, update it
            if (endDateInput.value && endDateInput.value < this.value) {
                endDateInput.value = this.value;
            }
        });
        
        // Set max date on start date based on end date
        endDateInput.addEventListener('change', function() {
            startDateInput.max = this.value;
            
            // If start date is after end date, update it
            if (startDateInput.value && startDateInput.value > this.value) {
                startDateInput.value = this.value;
            }
        });
        
        // Set default values if not already set
        if (!startDateInput.value) {
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
            startDateInput.value = formatDate(thirtyDaysAgo);
        }
        
        if (!endDateInput.value) {
            const today = new Date();
            endDateInput.value = formatDate(today);
        }
    }
}

/**
 * Format date as YYYY-MM-DD
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Update attendance filter
 */
function updateAttendanceFilter() {
    const filterForm = document.getElementById('filter-form');
    if (filterForm) {
        filterForm.submit();
    }
}
