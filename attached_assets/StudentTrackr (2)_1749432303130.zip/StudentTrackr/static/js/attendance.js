/**
 * Attendance JavaScript
 * Handles camera-based attendance functionality
 */

// Global variables
let videoElement;
let canvasElement;
let captureButton;
let recognizeButton;
let streamActive = false;
let capturedImageData = null;
let recognizedStudents = [];
let attendanceStatus = {};

document.addEventListener('DOMContentLoaded', function() {
    // Initialize camera elements
    videoElement = document.getElementById('camera-feed');
    canvasElement = document.getElementById('capture-canvas');
    captureButton = document.getElementById('capture-button');
    recognizeButton = document.getElementById('recognize-button');
    
    // Check if on attendance page with camera
    if (videoElement && canvasElement) {
        // Initialize camera access
        setupCamera();
        
        // Setup capture button
        if (captureButton) {
            captureButton.addEventListener('click', captureImage);
        }
        
        // Setup recognize button
        if (recognizeButton) {
            recognizeButton.addEventListener('click', recognizeFaces);
        }
        
        // Setup attendance UI
        setupAttendanceUI();
    }
});

/**
 * Setup camera access
 */
async function setupCamera() {
    try {
        const constraints = {
            video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                facingMode: 'user'
            }
        };
        
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        videoElement.srcObject = stream;
        streamActive = true;
        
        // Show success message
        showAlert('Camera accessed successfully', 'success');
        
        // Enable capture button
        if (captureButton) {
            captureButton.disabled = false;
        }
    } catch (error) {
        console.error('Error accessing camera:', error);
        showAlert('Error accessing camera: ' + error.message, 'danger');
    }
}

/**
 * Capture image from camera
 */
function captureImage() {
    if (!streamActive) {
        showAlert('Camera not active. Please refresh the page.', 'warning');
        return;
    }
    
    // Get canvas context
    const context = canvasElement.getContext('2d');
    
    // Set canvas dimensions to match video
    canvasElement.width = videoElement.videoWidth;
    canvasElement.height = videoElement.videoHeight;
    
    // Draw video frame to canvas
    context.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
    
    // Get image data as base64 string
    capturedImageData = canvasElement.toDataURL('image/jpeg');
    
    // Show preview
    const previewElement = document.getElementById('captured-image');
    if (previewElement) {
        previewElement.src = capturedImageData;
        previewElement.style.display = 'block';
    }
    
    // Show capture successful message
    showAlert('Image captured successfully', 'success');
    
    // Enable recognize button
    if (recognizeButton) {
        recognizeButton.disabled = false;
    }
    
    // Show recognition container
    const recognitionContainer = document.getElementById('recognition-container');
    if (recognitionContainer) {
        recognitionContainer.style.display = 'block';
    }
}

/**
 * Recognize faces in captured image
 */
async function recognizeFaces() {
    if (!capturedImageData) {
        showAlert('No image captured. Please capture an image first.', 'warning');
        return;
    }
    
    // Show loading state
    showAlert('Recognizing faces...', 'info');
    if (recognizeButton) {
        recognizeButton.disabled = true;
        recognizeButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Recognizing...';
    }
    
    // Get class ID
    const classId = document.getElementById('class-id').value;
    
    try {
        // Prepare form data
        const formData = new FormData();
        formData.append('image', capturedImageData);
        formData.append('class_id', classId);
        
        // Send API request
        const response = await fetch('/api/recognize-faces', {
            method: 'POST',
            body: formData
        });
        
        // Parse response
        const data = await response.json();
        
        if (data.success) {
            // Show success message
            showAlert(`Recognized ${data.recognized_students.length} student(s) out of ${data.face_count} face(s) detected`, 'success');
            
            // Update UI with recognized students
            recognizedStudents = data.recognized_students;
            updateRecognizedStudentsUI();
        } else {
            // Show error message
            showAlert(data.message || 'Face recognition failed', 'danger');
        }
    } catch (error) {
        console.error('Error recognizing faces:', error);
        showAlert('Error recognizing faces: ' + error.message, 'danger');
    } finally {
        // Reset button state
        if (recognizeButton) {
            recognizeButton.disabled = false;
            recognizeButton.innerHTML = 'Recognize Faces';
        }
    }
}

/**
 * Update UI with recognized students
 */
function updateRecognizedStudentsUI() {
    const studentsContainer = document.getElementById('recognized-students');
    if (!studentsContainer) return;
    
    // Clear previous content
    studentsContainer.innerHTML = '';
    
    if (recognizedStudents.length === 0) {
        studentsContainer.innerHTML = '<div class="alert alert-warning">No students recognized. Try again with a clearer image.</div>';
        return;
    }
    
    // Create table
    const table = document.createElement('table');
    table.className = 'table table-hover';
    
    // Create header
    const thead = document.createElement('thead');
    thead.innerHTML = `
        <tr>
            <th>Name</th>
            <th>Roll Number</th>
            <th>Confidence</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    `;
    table.appendChild(thead);
    
    // Create body
    const tbody = document.createElement('tbody');
    
    recognizedStudents.forEach(student => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${student.name}</td>
            <td>${student.roll_number}</td>
            <td>${(student.confidence * 100).toFixed(1)}%</td>
            <td id="status-${student.id}">
                ${getStatusBadgeHTML(attendanceStatus[student.id] || 'pending')}
            </td>
            <td>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-sm btn-success" onclick="markAttendance(${student.id}, 'present')">
                        <i class="fas fa-check"></i> Present
                    </button>
                    <button type="button" class="btn btn-sm btn-warning" onclick="markAttendance(${student.id}, 'late')">
                        <i class="fas fa-clock"></i> Late
                    </button>
                    <button type="button" class="btn btn-sm btn-danger" onclick="markAttendance(${student.id}, 'absent')">
                        <i class="fas fa-times"></i> Absent
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(tr);
    });
    
    table.appendChild(tbody);
    studentsContainer.appendChild(table);
    
    // Show mark all buttons
    const markAllButtons = document.getElementById('mark-all-buttons');
    if (markAllButtons) {
        markAllButtons.style.display = 'block';
    }
}

/**
 * Mark attendance for a student
 */
async function markAttendance(studentId, status) {
    // Get class ID and date
    const classId = document.getElementById('class-id').value;
    const dateInput = document.getElementById('attendance-date');
    const date = dateInput ? dateInput.value : new Date().toISOString().split('T')[0];
    
    try {
        // Send API request
        const response = await fetch('/api/mark-attendance', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                student_id: studentId,
                class_id: classId,
                status: status,
                date: date,
                method: 'face_recognition'
            })
        });
        
        // Parse response
        const data = await response.json();
        
        if (data.success) {
            // Update UI
            attendanceStatus[studentId] = status;
            
            const statusElement = document.getElementById(`status-${studentId}`);
            if (statusElement) {
                statusElement.innerHTML = getStatusBadgeHTML(status);
                
                // Add animation
                statusElement.classList.add('mark-attendance-animation');
                setTimeout(() => {
                    statusElement.classList.remove('mark-attendance-animation');
                }, 500);
            }
            
            // Show success message
            showAlert(data.message, 'success');
        } else {
            // Show error message
            showAlert(data.message || 'Failed to mark attendance', 'danger');
        }
    } catch (error) {
        console.error('Error marking attendance:', error);
        showAlert('Error marking attendance: ' + error.message, 'danger');
    }
}

/**
 * Mark attendance for all recognized students
 */
function markAllAttendance(status) {
    if (recognizedStudents.length === 0) {
        showAlert('No students recognized yet', 'warning');
        return;
    }
    
    // Confirm action
    if (confirm(`Are you sure you want to mark all ${recognizedStudents.length} students as ${status}?`)) {
        // Mark each student
        recognizedStudents.forEach(student => {
            markAttendance(student.id, status);
        });
    }
}

/**
 * Get HTML for status badge
 */
function getStatusBadgeHTML(status) {
    if (status === 'present') {
        return '<span class="badge bg-success">Present</span>';
    } else if (status === 'late') {
        return '<span class="badge bg-warning">Late</span>';
    } else if (status === 'absent') {
        return '<span class="badge bg-danger">Absent</span>';
    } else {
        return '<span class="badge bg-secondary">Pending</span>';
    }
}

/**
 * Setup attendance UI elements
 */
function setupAttendanceUI() {
    // Setup mark all buttons
    const markAllPresentButton = document.getElementById('mark-all-present');
    const markAllLateButton = document.getElementById('mark-all-late');
    const markAllAbsentButton = document.getElementById('mark-all-absent');
    
    if (markAllPresentButton) {
        markAllPresentButton.addEventListener('click', () => markAllAttendance('present'));
    }
    
    if (markAllLateButton) {
        markAllLateButton.addEventListener('click', () => markAllAttendance('late'));
    }
    
    if (markAllAbsentButton) {
        markAllAbsentButton.addEventListener('click', () => markAllAttendance('absent'));
    }
}

/**
 * Show alert message
 */
function showAlert(message, type) {
    const alertsContainer = document.getElementById('alerts-container');
    if (!alertsContainer) return;
    
    // Create alert element
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to container
    alertsContainer.appendChild(alert);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            alertsContainer.removeChild(alert);
        }, 150);
    }, 5000);
}
