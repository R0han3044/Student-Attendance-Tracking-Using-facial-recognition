from datetime import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# Association table for many-to-many relationship between Class and Student
class_student = db.Table('class_student',
    db.Column('class_id', db.Integer, db.ForeignKey('class.id'), primary_key=True),
    db.Column('student_id', db.Integer, db.ForeignKey('student.id'), primary_key=True)
)

class User(UserMixin, db.Model):
    """User model for authentication"""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'student', 'teacher', 'parent'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)

    teacher_profile = db.relationship('Teacher', backref='user', uselist=False, lazy=True)
    student_profile = db.relationship('Student', backref='user', uselist=False, lazy=True)
    parent_profile = db.relationship('Parent', backref='user', uselist=False, lazy=True)

    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username}>'

class Teacher(db.Model):
    """Teacher model"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    subject = db.Column(db.String(100))

    classes = db.relationship('Class', backref='teacher', lazy=True)
    marked_attendance = db.relationship('Attendance', backref='teacher', lazy=True, foreign_keys='Attendance.marked_by')

    def __repr__(self):
        return f'<Teacher {self.first_name} {self.last_name}>'

class Student(db.Model):
    """Student model"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    roll_number = db.Column(db.String(20), unique=True, nullable=False)
    face_encoding = db.Column(db.LargeBinary)  # Stores the face encoding

    classes = db.relationship('Class', secondary=class_student, lazy='subquery',
                             backref=db.backref('students', lazy=True))
    attendance_records = db.relationship('Attendance', backref='student', lazy=True)
    parents = db.relationship('Parent', backref='student', lazy=True)

    def __repr__(self):
        return f'<Student {self.first_name} {self.last_name}>'

class Class(db.Model):
    """Class model"""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teacher.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    attendance_records = db.relationship('Attendance', backref='class_ref', lazy=True)

    def __repr__(self):
        return f'<Class {self.name}>'

class Parent(db.Model):
    """Parent model"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)

    def __repr__(self):
        return f'<Parent {self.first_name} {self.last_name}>'

class Attendance(db.Model):
    """Attendance model"""
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey('class.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time_in = db.Column(db.Time)
    status = db.Column(db.String(20), default='absent')  # 'present', 'absent', 'late'
    marked_by = db.Column(db.Integer, db.ForeignKey('teacher.id'))
    method = db.Column(db.String(20), default='manual')  # 'manual', 'face_recognition'
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Attendance {self.student_id} on {self.date}>'

class Notification(db.Model):
    """Notification model for attendance alerts"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='notifications')

    def __repr__(self):
        return f'<Notification {self.id} for User {self.user_id}>'