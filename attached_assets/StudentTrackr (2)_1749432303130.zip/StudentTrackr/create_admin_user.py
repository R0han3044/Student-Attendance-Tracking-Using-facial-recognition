"""
Script to create an admin user (teacher) for testing
"""
from app import db, app
from models import User, Teacher, Class
from werkzeug.security import generate_password_hash

def create_admin_user():
    """Create an admin user (teacher) for testing"""
    print("Creating admin teacher user...")
    
    # Check if the admin user already exists
    admin_user = User.query.filter_by(username="admin").first()
    if admin_user:
        print("Admin user already exists.")
        return admin_user
    
    # Create admin user
    admin_user = User(
        username="admin",
        email="admin@example.com",
        role="teacher",
        password_hash=generate_password_hash("adminpass")
    )
    
    # Create teacher profile
    admin_teacher = Teacher(
        user=admin_user,
        first_name="Admin",
        last_name="Teacher",
        subject="Computer Science"
    )
    
    db.session.add(admin_user)
    db.session.add(admin_teacher)
    db.session.commit()
    
    print(f"Admin teacher created with ID: {admin_teacher.id}")
    
    # Create a demo class
    demo_class = Class(
        name="Demo Class",
        description="A demonstration class for testing",
        teacher_id=admin_teacher.id
    )
    
    db.session.add(demo_class)
    db.session.commit()
    
    print(f"Demo class created with ID: {demo_class.id}")
    
    return admin_user

if __name__ == "__main__":
    with app.app_context():
        admin = create_admin_user()
        print(f"Admin created successfully: {admin.username}")
        print("You can log in with:")
        print("Username: admin")
        print("Password: adminpass")