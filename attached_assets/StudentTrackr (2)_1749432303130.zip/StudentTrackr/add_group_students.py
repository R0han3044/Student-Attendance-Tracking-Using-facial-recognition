"""
Script to add students from the group photo and train face recognition model
"""
import os
import sys
import cv2
import numpy as np
from app import app, db
from models import User, Student, Teacher, Class
from face_recognition_utils import detect_faces, encode_face
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def extract_individual_faces_from_group(image_path):
    """Extract individual face regions from the group photo"""
    try:
        # Read the image
        image = cv2.imread(image_path)
        if image is None:
            logger.error(f"Could not load image from {image_path}")
            return []
        
        # Detect faces in the group photo using the image array directly
        face_locations, processed_image = detect_faces(image)
        
        if not face_locations:
            logger.error("No faces detected in the group photo")
            return []
        
        logger.info(f"Detected {len(face_locations)} faces in the group photo")
        
        # Extract each face region
        individual_faces = []
        for i, (top, right, bottom, left) in enumerate(face_locations):
            # Extract face region with some padding
            padding = 20
            y_start = max(0, top - padding)
            y_end = min(image.shape[0], bottom + padding)
            x_start = max(0, left - padding)
            x_end = min(image.shape[1], right + padding)
            
            face_region = image[y_start:y_end, x_start:x_end]
            
            # Resize face to standard size for better encoding
            face_resized = cv2.resize(face_region, (200, 200))
            individual_faces.append((i, face_resized))
            
            # Save individual face for verification
            face_filename = f"extracted_face_{i+1}.jpg"
            cv2.imwrite(face_filename, face_resized)
            logger.info(f"Extracted and saved face {i+1} as {face_filename}")
        
        return individual_faces
    
    except Exception as e:
        logger.error(f"Error extracting faces: {e}")
        return []

def create_teacher_if_not_exists():
    """Create a teacher if none exists"""
    teacher = Teacher.query.first()
    if not teacher:
        # Create teacher user
        teacher_user = User(
            username="teacher1",
            email="teacher@school.edu",
            role="teacher"
        )
        teacher_user.set_password("password123")
        db.session.add(teacher_user)
        db.session.flush()
        
        # Create teacher profile
        teacher = Teacher(
            user_id=teacher_user.id,
            first_name="Dr. Sarah",
            last_name="Johnson",
            subject="Computer Science"
        )
        db.session.add(teacher)
        db.session.commit()
        logger.info("Created teacher account")
    
    return teacher

def create_class_if_not_exists(teacher_id):
    """Create a class if none exists"""
    class_obj = Class.query.first()
    if not class_obj:
        class_obj = Class(
            name="Computer Science 101",
            description="Introduction to Computer Science and Programming",
            teacher_id=teacher_id
        )
        db.session.add(class_obj)
        db.session.commit()
        logger.info("Created Computer Science class")
    
    return class_obj

def add_student_with_face_encoding(username, email, first_name, last_name, roll_number, face_image):
    """Add a student with face encoding from extracted face image"""
    try:
        # Check if student already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            logger.info(f"Student {username} already exists, skipping...")
            return None
        
        # Create user account
        user = User(
            username=username,
            email=email,
            role="student"
        )
        user.set_password("student123")  # Default password
        db.session.add(user)
        db.session.flush()
        
        # Encode the face
        face_encoding = encode_face_from_image(face_image)
        
        # Create student profile
        student = Student(
            user_id=user.id,
            first_name=first_name,
            last_name=last_name,
            roll_number=roll_number,
            face_encoding=face_encoding
        )
        db.session.add(student)
        db.session.commit()
        
        logger.info(f"Added student: {first_name} {last_name} ({username})")
        return student
        
    except Exception as e:
        logger.error(f"Error adding student {username}: {e}")
        db.session.rollback()
        return None

def encode_face_from_image(face_image):
    """Create face encoding from extracted face image"""
    try:
        # Save face image temporarily
        temp_filename = "temp_face.jpg"
        cv2.imwrite(temp_filename, face_image)
        
        # Get encoding
        encoding = encode_face(temp_filename)
        
        # Clean up
        if os.path.exists(temp_filename):
            os.remove(temp_filename)
        
        return encoding
        
    except Exception as e:
        logger.error(f"Error encoding face: {e}")
        return None

def add_students_to_class(class_obj):
    """Add all students to the class"""
    students = Student.query.all()
    for student in students:
        if student not in class_obj.students:
            class_obj.students.append(student)
    
    db.session.commit()
    logger.info(f"Added {len(students)} students to {class_obj.name}")

def main():
    """Main function to process the group photo and add students"""
    with app.app_context():
        # Path to the group photo
        group_photo_path = "attached_assets/download_1749397125961.jpg"
        
        # Extract individual faces
        individual_faces = extract_individual_faces_from_group(group_photo_path)
        
        if not individual_faces:
            logger.error("No faces could be extracted from the group photo")
            return
        
        # Create teacher and class if they don't exist
        teacher = create_teacher_if_not_exists()
        class_obj = create_class_if_not_exists(teacher.id)
        
        # Student data - based on the positions in the photo (left to right)
        student_data = [
            ("alex_chen", "alex.chen@student.edu", "Alex", "Chen", "CS001"),
            ("maria_garcia", "maria.garcia@student.edu", "Maria", "Garcia", "CS002"),
            ("james_smith", "james.smith@student.edu", "James", "Smith", "CS003"),
            ("emma_johnson", "emma.johnson@student.edu", "Emma", "Johnson", "CS004"),
            ("sophia_williams", "sophia.williams@student.edu", "Sophia", "Williams", "CS005")
        ]
        
        # Add each student with their corresponding face
        for i, (face_index, face_image) in enumerate(individual_faces):
            if i < len(student_data):
                username, email, first_name, last_name, roll_number = student_data[i]
                student = add_student_with_face_encoding(
                    username, email, first_name, last_name, roll_number, face_image
                )
                
                if student:
                    logger.info(f"Successfully added student {first_name} {last_name}")
                else:
                    logger.error(f"Failed to add student {first_name} {last_name}")
        
        # Add all students to the class
        add_students_to_class(class_obj)
        
        logger.info("Face recognition model training complete!")
        logger.info("Students can now log in with username and password 'student123'")
        logger.info("Teacher can log in with username 'teacher1' and password 'password123'")

if __name__ == "__main__":
    main()