"""
Script to add notifications for parents
"""
import logging
from datetime import datetime, timedelta
from app import app, db
from models import User, Student, Parent, Attendance, Notification

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def add_parent_notifications():
    """Add notifications for parents about their children's attendance"""
    with app.app_context():
        # Get all parents
        parents = Parent.query.all()
        
        if not parents:
            logger.warning("No parents found in the database")
            return
        
        logger.info(f"Found {len(parents)} parents to add notifications for")
        
        for parent in parents:
            user = User.query.get(parent.user_id)
            student = Student.query.get(parent.student_id)
            
            if not student:
                logger.warning(f"No student found for parent {parent.first_name} {parent.last_name}")
                continue
            
            logger.info(f"Adding notifications for parent {parent.first_name} {parent.last_name} of {student.first_name} {student.last_name}")
            
            # Find absences in the last 30 days
            today = datetime.now().date()
            thirty_days_ago = today - timedelta(days=30)
            
            absences = Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.status == 'absent',
                Attendance.date >= thirty_days_ago
            ).all()
            
            # Create absence notifications
            for i, absence in enumerate(absences[:3]):  # Limit to 3 absence notifications
                notification = Notification(
                    user_id=user.id,
                    title=f"Absence Alert: {student.first_name} {student.last_name}",
                    message=f"Your child was absent on {absence.date.strftime('%A, %B %d, %Y')} for the {absence.class_ref.name} class.",
                    is_read=False,
                    created_at=datetime.utcnow() - timedelta(days=29-i*2)  # Space them out
                )
                db.session.add(notification)
            
            # Create a welcome notification
            welcome_notification = Notification(
                user_id=user.id,
                title="Welcome to the Parent Dashboard",
                message=f"Welcome to the Parent Dashboard! You can now track {student.first_name}'s attendance and receive real-time notifications.",
                is_read=False,
                created_at=datetime.utcnow() - timedelta(days=30)
            )
            db.session.add(welcome_notification)
            
            # Create a perfect attendance notification if applicable
            perfect_attendance = not Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.status == 'absent',
                Attendance.date >= today - timedelta(days=7)
            ).first()
            
            if perfect_attendance:
                perfect_notification = Notification(
                    user_id=user.id,
                    title="Perfect Attendance This Week!",
                    message=f"Congratulations! {student.first_name} had perfect attendance this week.",
                    is_read=False,
                    created_at=datetime.utcnow() - timedelta(days=1)
                )
                db.session.add(perfect_notification)
            
            # Commit changes for each parent
            db.session.commit()
            logger.info(f"Added notifications for parent of {student.first_name} {student.last_name}")
        
        logger.info("Parent notifications generation complete")

if __name__ == "__main__":
    add_parent_notifications()
    logger.info("Script completed successfully")