"""
Simple script to add students from group photo with direct face processing
"""
import os
import cv2
import numpy as np
from app import app, db
from models import User, Student, Teacher, Class
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_simple_face_encoding(face_image):
    """Create a simple face encoding using image features"""
    try:
        # Convert to grayscale
        if len(face_image.shape) == 3:
            gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
        else:
            gray = face_image
        
        # Resize to standard size
        resized = cv2.resize(gray, (100, 100))
        
        # Apply histogram equalization
        equalized = cv2.equalizeHist(resized)
        
        # Create feature vector from image statistics
        features = []
        
        # Add pixel intensity statistics
        features.extend([
            np.mean(equalized),
            np.std(equalized),
            np.median(equalized),
            np.min(equalized),
            np.max(equalized)
        ])
        
        # Add texture features (simple gradients)
        grad_x = cv2.Sobel(equalized, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(equalized, cv2.CV_64F, 0, 1, ksize=3)
        
        features.extend([
            np.mean(grad_x),
            np.std(grad_x),
            np.mean(grad_y),
            np.std(grad_y)
        ])
        
        # Convert to numpy array and then to bytes for storage
        feature_array = np.array(features, dtype=np.float64)
        return feature_array.tobytes()
        
    except Exception as e:
        logger.error(f"Error creating face encoding: {e}")
        return None

def extract_faces_from_group_photo(image_path):
    """Extract faces from group photo using OpenCV"""
    try:
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            logger.error(f"Could not load image: {image_path}")
            return []
        
        # Convert to grayscale for face detection
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Load face detector
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        # Detect faces with more sensitive parameters
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.05, minNeighbors=2, minSize=(20, 20))
        
        # If still not enough faces, try alternative cascade
        if len(faces) < 4:
            face_cascade_alt = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_alt.xml')
            faces_alt = face_cascade_alt.detectMultiScale(gray, scaleFactor=1.05, minNeighbors=2, minSize=(20, 20))
            
            # Use whichever detected more faces
            if len(faces_alt) > len(faces):
                faces = faces_alt
                logger.info(f"Using alternative cascade, detected {len(faces)} faces")
        
        logger.info(f"Detected {len(faces)} faces in group photo")
        
        # Extract each face
        extracted_faces = []
        for i, (x, y, w, h) in enumerate(faces):
            # Extract face region with padding
            padding = 20
            x_start = max(0, x - padding)
            y_start = max(0, y - padding)
            x_end = min(image.shape[1], x + w + padding)
            y_end = min(image.shape[0], y + h + padding)
            
            face_roi = image[y_start:y_end, x_start:x_end]
            
            # Resize for consistency
            face_resized = cv2.resize(face_roi, (150, 150))
            
            # Save for verification
            face_filename = f"student_face_{i+1}.jpg"
            cv2.imwrite(face_filename, face_resized)
            
            # Create encoding
            encoding = create_simple_face_encoding(face_resized)
            
            if encoding:
                extracted_faces.append((i, face_resized, encoding))
                logger.info(f"Successfully processed face {i+1}")
            else:
                logger.warning(f"Failed to encode face {i+1}")
        
        return extracted_faces
        
    except Exception as e:
        logger.error(f"Error extracting faces: {e}")
        return []

def setup_database():
    """Setup teacher and class"""
    # Create teacher if needed
    teacher = Teacher.query.first()
    if not teacher:
        teacher_user = User()
        teacher_user.username = "teacher1"
        teacher_user.email = "teacher@school.edu"
        teacher_user.role = "teacher"
        teacher_user.set_password("password123")
        db.session.add(teacher_user)
        db.session.flush()
        
        teacher = Teacher()
        teacher.user_id = teacher_user.id
        teacher.first_name = "Dr. Sarah"
        teacher.last_name = "Johnson"
        teacher.subject = "Computer Science"
        db.session.add(teacher)
        db.session.commit()
        logger.info("Created teacher account")
    
    # Create class if needed
    class_obj = Class.query.first()
    if not class_obj:
        class_obj = Class()
        class_obj.name = "Computer Science 101"
        class_obj.description = "Introduction to Computer Science and Programming"
        class_obj.teacher_id = teacher.id
        db.session.add(class_obj)
        db.session.commit()
        logger.info("Created class")
    
    return teacher, class_obj

def add_student(username, email, first_name, last_name, roll_number, face_encoding):
    """Add student to database"""
    try:
        # Check if exists
        if User.query.filter_by(username=username).first():
            logger.info(f"Student {username} already exists")
            return None
        
        # Create user
        user = User()
        user.username = username
        user.email = email
        user.role = "student"
        user.set_password("student123")
        db.session.add(user)
        db.session.flush()
        
        # Create student
        student = Student()
        student.user_id = user.id
        student.first_name = first_name
        student.last_name = last_name
        student.roll_number = roll_number
        student.face_encoding = face_encoding
        db.session.add(student)
        db.session.commit()
        
        logger.info(f"Added student: {first_name} {last_name}")
        return student
        
    except Exception as e:
        logger.error(f"Error adding student {username}: {e}")
        db.session.rollback()
        return None

def main():
    """Main function"""
    with app.app_context():
        # Extract faces from group photo
        faces = extract_faces_from_group_photo("attached_assets/download_1749397125961.jpg")
        
        if not faces:
            logger.error("No faces extracted")
            return
        
        # Setup database
        teacher, class_obj = setup_database()
        
        # Student data (left to right in photo)
        students_data = [
            ("alex_chen", "alex.chen@student.edu", "Alex", "Chen", "CS001"),
            ("maria_garcia", "maria.garcia@student.edu", "Maria", "Garcia", "CS002"),
            ("james_smith", "james.smith@student.edu", "James", "Smith", "CS003"),
            ("emma_johnson", "emma.johnson@student.edu", "Emma", "Johnson", "CS004"),
            ("sophia_williams", "sophia.williams@student.edu", "Sophia", "Williams", "CS005")
        ]
        
        # Add students
        added_count = 0
        for face_index, face_image, face_encoding in faces:
            if face_index < len(students_data):
                username, email, first_name, last_name, roll_number = students_data[face_index]
                student = add_student(username, email, first_name, last_name, roll_number, face_encoding)
                
                if student:
                    # Add to class
                    if student not in class_obj.students:
                        class_obj.students.append(student)
                    added_count += 1
        
        db.session.commit()
        
        logger.info(f"Successfully added {added_count} students with face recognition training")
        logger.info("Login credentials:")
        logger.info("- Teacher: username='teacher1', password='password123'")
        logger.info("- Students: username as shown above, password='student123'")

if __name__ == "__main__":
    main()