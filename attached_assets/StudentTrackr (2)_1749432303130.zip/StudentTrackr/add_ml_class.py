"""
Script to create a Machine Learning class and add students to it
"""
from app import app, db
from models import User, Student, Teacher, Class

def create_ml_class():
    """Create a Machine Learning class if it doesn't already exist"""
    # Check if ML class already exists
    existing_class = Class.query.filter_by(name="Machine Learning").first()
    if existing_class:
        print("Machine Learning class already exists.")
        return existing_class
    
    # Get the admin teacher
    admin_teacher = Teacher.query.join(User).filter(User.username == "admin").first()
    if not admin_teacher:
        print("Admin teacher not found. Please run create_admin_user.py first.")
        return None
    
    # Create the ML class
    ml_class = Class(
        name="Machine Learning",
        description="Introduction to Machine Learning and AI concepts with hands-on projects.",
        teacher_id=admin_teacher.id
    )
    
    db.session.add(ml_class)
    db.session.commit()
    
    print(f"Created Machine Learning class with ID: {ml_class.id}")
    return ml_class

def add_students_to_ml_class():
    """Add students to the Machine Learning class"""
    # Get the ML class (or create it if it doesn't exist)
    ml_class = create_ml_class()
    if not ml_class:
        return
    
    # Get the students
    students = Student.query.all()
    if not students:
        print("No students found. Please run add_students.py first.")
        return
    
    # Add each student to the class
    for student in students:
        if student not in ml_class.students:
            ml_class.students.append(student)
            print(f"Added {student.first_name} {student.last_name} to Machine Learning class")
        else:
            print(f"{student.first_name} {student.last_name} is already enrolled in Machine Learning class")
    
    db.session.commit()
    print("All students have been added to the Machine Learning class!")

if __name__ == "__main__":
    with app.app_context():
        add_students_to_ml_class()