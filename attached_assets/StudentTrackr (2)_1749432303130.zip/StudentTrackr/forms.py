from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectField, TextAreaField, DateField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError, Optional
from datetime import date
from models import User, Student

class LoginForm(FlaskForm):
    """Login form"""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')

class RegistrationForm(FlaskForm):
    """Registration form"""
    role = SelectField('Register as', choices=[
        ('student', 'Student'), 
        ('teacher', 'Teacher'), 
        ('parent', 'Parent')
    ], validators=[DataRequired()])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=50)])
    
    # Role-specific fields
    # Student
    roll_number = StringField('Roll Number', validators=[Length(max=20)])
    
    # Teacher
    subject = StringField('Subject', validators=[Length(max=100)])
    
    # Parent
    phone = StringField('Phone Number', validators=[Length(max=20)])
    student_roll_number = StringField('Student Roll Number', validators=[Length(max=20)])
    
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        """Validate username is unique"""
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_email(self, email):
        """Validate email is unique"""
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different one.')
    
    def validate_roll_number(self, roll_number):
        """Validate roll number is unique if provided"""
        if self.role.data == 'student' and roll_number.data:
            student = Student.query.filter_by(roll_number=roll_number.data).first()
            if student:
                raise ValidationError('Roll number already exists. Please use a different one.')
    
    def validate_student_roll_number(self, student_roll_number):
        """Validate student roll number exists if provided"""
        if self.role.data == 'parent' and student_roll_number.data:
            student = Student.query.filter_by(roll_number=student_roll_number.data).first()
            if not student:
                raise ValidationError('Student with this roll number does not exist.')

class UploadFaceForm(FlaskForm):
    """Form for uploading face images"""
    face_image = FileField('Face Image', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png'], 'Images only!')
    ])
    submit = SubmitField('Upload')

class AddStudentForm(FlaskForm):
    """Form for adding a student"""
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=50)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    roll_number = StringField('Roll Number', validators=[DataRequired(), Length(max=20)])
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=64)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Add Student')
    
    def validate_username(self, username):
        """Validate username is unique"""
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already taken. Please choose a different one.')
    
    def validate_email(self, email):
        """Validate email is unique"""
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please use a different one.')
    
    def validate_roll_number(self, roll_number):
        """Validate roll number is unique"""
        student = Student.query.filter_by(roll_number=roll_number.data).first()
        if student:
            raise ValidationError('Roll number already exists. Please use a different one.')

class AddClassForm(FlaskForm):
    """Form for adding a class"""
    name = StringField('Class Name', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Description', validators=[Optional(), Length(max=500)])
    submit = SubmitField('Add Class')

class TakeAttendanceForm(FlaskForm):
    """Form for taking attendance manually"""
    class_id = SelectField('Class', coerce=int, validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()], default=date.today)
    submit = SubmitField('Take Attendance')

class StudentAttendanceForm(FlaskForm):
    """Form for marking individual student attendance"""
    status = SelectField('Status', choices=[
        ('present', 'Present'),
        ('late', 'Late'),
        ('absent', 'Absent')
    ], validators=[DataRequired()])
    notes = TextAreaField('Notes', validators=[Optional(), Length(max=200)])
    submit = SubmitField('Mark Attendance')
