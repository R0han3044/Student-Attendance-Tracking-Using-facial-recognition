"""
Script to add new students with face encodings to the system
"""
import os
import logging
from app import app, db
from models import User, Student, Class, Teacher
from face_recognition_utils import encode_face
from werkzeug.security import generate_password_hash
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Student information
NEW_STUDENTS = [
    {
        "username": "sathwik.reddy.2023",
        "email": "sathwik.reddy.2023@example.com",
        "password": "pass123",
        "first_name": "Sathwik",
        "last_name": "Reddy",
        "roll_number": "ST004",
        "image_path": "static/uploads/students/sathwik_reddy.jpg"
    },
    {
        "username": "prathyusha.mudhiraj",
        "email": "prathyusha.mudhiraj@example.com",
        "password": "pass123",
        "first_name": "Prathyusha",
        "last_name": "Mudhiraj",
        "roll_number": "ST005",
        "image_path": "static/uploads/students/prathyusha_mudhiraj.jpg"
    },
    {
        "username": "nithin.naik",
        "email": "nithin.naik@example.com",
        "password": "pass123",
        "first_name": "Nithin",
        "last_name": "Naik",
        "roll_number": "ST006",
        "image_path": "static/uploads/students/nithin_naik.jpg"
    }
]

def add_student(username, email, password, first_name, last_name, roll_number, image_path=None):
    """Add a student to the database with face encoding if image is provided"""
    with app.app_context():
        # Check if student already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            logger.info(f"Student {username} already exists, skipping")
            return existing_user.student_profile
        
        # Check if roll number already exists
        existing_roll = Student.query.filter_by(roll_number=roll_number).first()
        if existing_roll:
            logger.warning(f"Roll number {roll_number} already exists, changing to unique value")
            # Generate a unique roll number
            roll_number = f"{roll_number}_NEW"
        
        logger.info(f"Adding student: {first_name} {last_name} ({username})")
        
        # Create user
        user = User(
            username=username,
            email=email,
            role='student',
            created_at=datetime.utcnow()
        )
        user.set_password(password)
        db.session.add(user)
        db.session.flush()
        
        # Create student profile
        student = Student(
            user_id=user.id,
            first_name=first_name,
            last_name=last_name,
            roll_number=roll_number
        )
        
        # Process face image if provided
        if image_path and os.path.exists(image_path):
            logger.info(f"Processing face image from {image_path}")
            try:
                with open(image_path, 'rb') as img_file:
                    image_data = img_file.read()
                
                # Generate face encoding
                face_encoding = encode_face(image_data)
                
                if face_encoding:
                    logger.info(f"Successfully encoded face for {first_name} {last_name}")
                    student.face_encoding = face_encoding
                else:
                    logger.error(f"Failed to encode face for {first_name} {last_name}")
            except Exception as e:
                logger.error(f"Error processing image {image_path}: {str(e)}")
        
        db.session.add(student)
        
        # Add student to Machine Learning class if it exists
        ml_class = Class.query.filter_by(name="Machine Learning").first()
        if ml_class:
            logger.info(f"Adding {first_name} {last_name} to Machine Learning class")
            ml_class.students.append(student)
        
        db.session.commit()
        logger.info(f"Successfully added student: {first_name} {last_name}")
        return student

def create_ml_class_if_not_exists():
    """Create a Machine Learning class if it doesn't already exist"""
    with app.app_context():
        ml_class = Class.query.filter_by(name="Machine Learning").first()
        if ml_class:
            logger.info("Machine Learning class already exists")
            return ml_class
        
        # Get a teacher for the class
        teacher = Teacher.query.first()
        if not teacher:
            logger.error("No teacher found in the database, cannot create class")
            return None
        
        logger.info(f"Creating Machine Learning class with teacher ID {teacher.id}")
        ml_class = Class(
            name="Machine Learning",
            description="Advanced course on machine learning concepts and implementations",
            teacher_id=teacher.id,
            created_at=datetime.utcnow()
        )
        db.session.add(ml_class)
        db.session.commit()
        logger.info("Successfully created Machine Learning class")
        return ml_class

def add_all_students():
    """Add all new students to the database"""
    for student_data in NEW_STUDENTS:
        add_student(
            username=student_data["username"],
            email=student_data["email"],
            password=student_data["password"],
            first_name=student_data["first_name"],
            last_name=student_data["last_name"],
            roll_number=student_data["roll_number"],
            image_path=student_data["image_path"]
        )

if __name__ == "__main__":
    # Create ML class if needed
    create_ml_class_if_not_exists()
    
    # Add all students
    add_all_students()
    
    logger.info("Script completed successfully")