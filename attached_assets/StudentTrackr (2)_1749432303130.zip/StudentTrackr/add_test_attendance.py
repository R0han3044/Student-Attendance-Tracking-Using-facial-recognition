"""
Script to add test attendance records for students
"""
import logging
from datetime import datetime, timedelta
from app import app, db
from models import User, Student, Class, Attendance
import random

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def add_attendance_records():
    """Add test attendance records for students"""
    with app.app_context():
        # Get all students
        students = Student.query.all()
        
        if not students:
            logger.warning("No students found in the database")
            return
        
        logger.info(f"Found {len(students)} students to add attendance for")
        
        # Get the Machine Learning class
        ml_class = Class.query.filter_by(name="Machine Learning").first()
        
        if not ml_class:
            logger.warning("Machine Learning class not found")
            return
        
        logger.info(f"Adding attendance records for class: {ml_class.name}")
        
        # Generate attendance for the last 30 days
        today = datetime.now().date()
        num_days = 30
        
        for student in students:
            logger.info(f"Adding attendance for {student.first_name} {student.last_name}")
            
            # Delete any existing attendance records for this student and class
            Attendance.query.filter_by(student_id=student.id, class_id=ml_class.id).delete()
            
            # Add new random attendance for each day
            for day_offset in range(num_days):
                record_date = today - timedelta(days=day_offset)
                
                # Skip weekends (6 = Saturday, 0 = Sunday)
                if record_date.weekday() >= 5:
                    continue
                
                # Randomly determine status (weighted towards present)
                status_weights = {'present': 0.7, 'late': 0.2, 'absent': 0.1}
                status = random.choices(
                    list(status_weights.keys()),
                    weights=list(status_weights.values()),
                    k=1
                )[0]
                
                # Set time_in based on status
                time_in = None
                if status in ['present', 'late']:
                    base_hour = 9 if status == 'present' else 9 + random.randint(1, 2)
                    base_minute = random.randint(0, 59)
                    time_in = datetime.now().replace(hour=base_hour, minute=base_minute).time()
                
                # Create attendance record
                attendance = Attendance(
                    student_id=student.id,
                    class_id=ml_class.id,
                    date=record_date,
                    time_in=time_in,
                    status=status,
                    method='face_recognition' if random.random() > 0.3 else 'manual',
                    notes='Generated for testing' if random.random() > 0.8 else None,
                    created_at=datetime.utcnow()
                )
                
                db.session.add(attendance)
            
            # Commit changes for each student
            db.session.commit()
            logger.info(f"Added attendance records for {student.first_name} {student.last_name}")
        
        logger.info("Attendance records generation complete")

if __name__ == "__main__":
    add_attendance_records()
    logger.info("Script completed successfully")