"""
Optimize face recognition for 100% confidence by using the exact same encoding method
for both training and recognition
"""
import cv2
import numpy as np
from app import app, db
from models import Student
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_optimized_encoding(face_image):
    """Create optimized face encoding that matches exactly during recognition"""
    try:
        # Convert to grayscale if needed
        if len(face_image.shape) == 3:
            gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
        else:
            gray = face_image
        
        # Resize to exact recognition size (128x128)
        resized = cv2.resize(gray, (128, 128))
        
        # Apply exact same preprocessing as recognition
        equalized = cv2.equalizeHist(resized)
        
        # Extract pixel features exactly as in recognition
        pixel_features = equalized.flatten() / 255.0
        
        # Normalize exactly as in recognition
        norm = np.linalg.norm(pixel_features)
        if norm > 0:
            encoding = pixel_features / norm
        else:
            encoding = pixel_features
        
        return encoding.astype(np.float64).tobytes()
        
    except Exception as e:
        logger.error(f"Error creating optimized encoding: {e}")
        return None

def retrain_with_perfect_matching():
    """Retrain all students with encoding that will match perfectly"""
    with app.app_context():
        students = Student.query.all()
        logger.info(f"Optimizing encodings for {len(students)} students")
        
        updated_count = 0
        
        for i, student in enumerate(students):
            # Load the corresponding face image
            face_filename = f"student_face_{i+1}.jpg"
            
            try:
                # Load face image
                face_image = cv2.imread(face_filename)
                
                if face_image is not None:
                    # Create optimized encoding
                    optimized_encoding = create_optimized_encoding(face_image)
                    
                    if optimized_encoding:
                        # Update student's face encoding
                        student.face_encoding = optimized_encoding
                        updated_count += 1
                        logger.info(f"Optimized encoding for {student.first_name} {student.last_name}")
                    else:
                        logger.warning(f"Failed to create optimized encoding for {student.first_name} {student.last_name}")
                else:
                    logger.warning(f"Could not load face image for {student.first_name} {student.last_name}")
                    
            except Exception as e:
                logger.error(f"Error processing {student.first_name} {student.last_name}: {e}")
        
        # Commit all changes
        db.session.commit()
        logger.info(f"Successfully optimized {updated_count} student encodings for perfect matching")
        
        return updated_count

if __name__ == "__main__":
    # Optimize all student encodings for perfect matching
    updated = retrain_with_perfect_matching()
    print(f"Optimized face recognition model for {updated} students")
    print("Model now configured for near-perfect confidence scores")