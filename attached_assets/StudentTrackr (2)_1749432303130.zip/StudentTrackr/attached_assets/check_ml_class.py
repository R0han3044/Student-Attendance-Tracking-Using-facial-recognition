from app import app
from models import Class, Student, Teacher

def check_ml_class():
    with app.app_context():
        ml_class = Class.query.filter_by(name='Machine Learning').first()
        
        if not ml_class:
            print("Machine Learning class does not exist.")
            return
            
        teacher = Teacher.query.get(ml_class.teacher_id)
        
        print(f"\nMachine Learning Class (ID: {ml_class.id})")
        print(f"Teacher: {teacher.first_name} {teacher.last_name}")
        
        print("\nEnrolled Students:")
        if ml_class.students:
            for student in ml_class.students:
                print(f"- {student.first_name} {student.last_name} (Roll: {student.roll_number})")
        else:
            print("No students enrolled in this class.")

if __name__ == "__main__":
    check_ml_class()