/**
 * Webcam utility for capturing images from the webcam
 */
class Webcam {
    constructor(videoElement, constraints = null) {
        this.videoElement = videoElement;
        this.constraints = constraints || {
            video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                facingMode: "user"
            },
            audio: false
        };
        this.stream = null;
    }

    /**
     * Start the webcam
     * @returns {Promise} Promise that resolves when the webcam is started
     */
    async start() {
        try {
            this.stream = await navigator.mediaDevices.getUserMedia(this.constraints);
            this.videoElement.srcObject = this.stream;
            return new Promise((resolve) => {
                this.videoElement.onloadedmetadata = () => {
                    resolve();
                };
            });
        } catch (error) {
            console.error("Error starting webcam:", error);
            throw error;
        }
    }

    /**
     * Stop the webcam
     */
    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
            this.videoElement.srcObject = null;
        }
    }

    /**
     * Take a picture from the webcam
     * @returns {string} Base64 encoded image data
     */
    takePicture() {
        const canvas = document.createElement('canvas');
        canvas.width = this.videoElement.videoWidth;
        canvas.height = this.videoElement.videoHeight;
        const context = canvas.getContext('2d');
        
        // Draw the current video frame
        context.drawImage(this.videoElement, 0, 0, canvas.width, canvas.height);
        
        // Get the image as a base64 string
        return canvas.toDataURL('image/jpeg');
    }
}

export default Webcam;
