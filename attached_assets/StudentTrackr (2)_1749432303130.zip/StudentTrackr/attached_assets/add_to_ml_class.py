from app import app, db
from models import Class, Student, Teacher, User

def create_ml_class_if_not_exists():
    """Create a Machine Learning class if it doesn't already exist"""
    # Check if ML class already exists
    ml_class = Class.query.filter_by(name='Machine Learning').first()
    
    if ml_class:
        print(f"Machine Learning class already exists with ID: {ml_class.id}")
        return ml_class
    
    # Get a teacher to assign to the class
    teacher = Teacher.query.first()
    if not teacher:
        print("No teachers found in the database. Please add a teacher first.")
        return None
    
    # Create the ML class
    ml_class = Class(
        name='Machine Learning',
        teacher_id=teacher.id
    )
    
    db.session.add(ml_class)
    db.session.commit()
    print(f"Created new Machine Learning class with ID: {ml_class.id}")
    return ml_class

def add_students_to_ml_class():
    """Add Nithin, Sathwik, and Prathyusha to the Machine Learning class"""
    # Get or create the ML class
    ml_class = create_ml_class_if_not_exists()
    if not ml_class:
        return
    
    # Get the students
    student_names = ['Nithin', 'Sathwik', 'Prathyusha']
    for first_name in student_names:
        student = Student.query.filter_by(first_name=first_name).first()
        if not student:
            print(f"Student {first_name} not found in the database.")
            continue
        
        # Check if student is already in the class
        if student in ml_class.students:
            print(f"{student.first_name} {student.last_name} is already enrolled in Machine Learning class.")
            continue
        
        # Add student to the class
        ml_class.students.append(student)
        print(f"Added {student.first_name} {student.last_name} to Machine Learning class.")
    
    db.session.commit()
    print(f"All available students have been added to Machine Learning class.")
    
    # Print the final class roster
    print("\nMachine Learning Class Roster:")
    for student in ml_class.students:
        print(f"- {student.first_name} {student.last_name} (Roll Number: {student.roll_number})")

if __name__ == "__main__":
    with app.app_context():
        add_students_to_ml_class()