from datetime import datetime, date, timedelta
from models import Attendance, Student, Class
import json

def get_attendance_statistics(student_id=None, class_id=None, teacher_id=None, date_range=None):
    """
    Get attendance statistics for a student, class, or teacher
    
    Parameters:
    - student_id: ID of the student to get statistics for
    - class_id: ID of the class to get statistics for
    - teacher_id: ID of the teacher to get statistics for
    - date_range: Tuple of (start_date, end_date) to limit the date range
    
    Returns a dictionary with attendance statistics
    """
    # Set default date range to the last 30 days if not provided
    if not date_range:
        end_date = date.today()
        start_date = end_date - timedelta(days=30)
    else:
        start_date, end_date = date_range
    
    # Build the query based on provided parameters
    query = Attendance.query.filter(
        Attendance.date >= start_date,
        Attendance.date <= end_date
    )
    
    if student_id:
        query = query.filter(Attendance.student_id == student_id)
    
    if class_id:
        query = query.filter(Attendance.class_id == class_id)
    
    if teacher_id:
        query = query.filter(Attendance.marked_by == teacher_id)
    
    # Get all attendance records matching the query
    records = query.all()
    
    # Calculate statistics
    total_records = len(records)
    present_records = sum(1 for record in records if record.status == 'present')
    late_records = sum(1 for record in records if record.status == 'late')
    absent_records = sum(1 for record in records if record.status == 'absent')
    
    # Calculate attendance rate
    if total_records > 0:
        attendance_rate = (present_records + late_records) / total_records * 100
    else:
        attendance_rate = 0
    
    # Organize records by date
    records_by_date = {}
    for record in records:
        date_str = record.date.strftime('%Y-%m-%d')
        if date_str not in records_by_date:
            records_by_date[date_str] = {'present': 0, 'late': 0, 'absent': 0}
        
        records_by_date[date_str][record.status] += 1
    
    return {
        'total': total_records,
        'present': present_records,
        'late': late_records,
        'absent': absent_records,
        'attendance_rate': round(attendance_rate, 1),
        'records_by_date': records_by_date
    }

def generate_chart_data(statistics):
    """
    Generate data for a Chart.js chart based on attendance statistics
    
    Parameters:
    - statistics: Dictionary of attendance statistics from get_attendance_statistics()
    
    Returns a dictionary with chart data
    """
    # Get the records by date
    records_by_date = statistics['records_by_date']
    
    # Sort dates
    dates = sorted(records_by_date.keys())
    
    # Prepare datasets
    present_data = [records_by_date[date]['present'] for date in dates]
    late_data = [records_by_date[date]['late'] for date in dates]
    absent_data = [records_by_date[date]['absent'] for date in dates]
    
    # Format dates for display
    formatted_dates = [datetime.strptime(date, '%Y-%m-%d').strftime('%b %d') for date in dates]
    
    return {
        'labels': formatted_dates,
        'datasets': [
            {
                'label': 'Present',
                'data': present_data,
                'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                'borderColor': 'rgba(75, 192, 192, 1)',
                'borderWidth': 1
            },
            {
                'label': 'Late',
                'data': late_data,
                'backgroundColor': 'rgba(255, 206, 86, 0.2)',
                'borderColor': 'rgba(255, 206, 86, 1)',
                'borderWidth': 1
            },
            {
                'label': 'Absent',
                'data': absent_data,
                'backgroundColor': 'rgba(255, 99, 132, 0.2)',
                'borderColor': 'rgba(255, 99, 132, 1)',
                'borderWidth': 1
            }
        ]
    }
