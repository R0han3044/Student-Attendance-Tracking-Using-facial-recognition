from app import app, db
from models import User
from flask import session

def test_login():
    with app.test_client() as client:
        print("Testing login functionality...")
        
        # Make sure flask secret key is set
        print(f"Flask secret key is {'set' if app.secret_key else 'NOT SET'}")
        
        # Test login with teacher1
        response = client.post('/login', data={
            'username': 'teacher1',
            'password': 'password'
        }, follow_redirects=True)
        
        # Check response
        content = response.data.decode('utf-8')
        print(f"Status code: {response.status_code}")
        print(f"Login successful: {'Login successful' in content}")
        print(f"Error message: {'Invalid username or password' in content}")
        
        if 'Invalid username or password' in content:
            print("\nLogin failed. Creating new test account...")
            
            # Create a test account directly through app context
            with app.app_context():
                # Check if test_teacher exists
                test_user = User.query.filter_by(username='test_teacher').first()
                
                if not test_user:
                    # Create test teacher account
                    test_user = User(username='test_teacher', email='test_teacher@example.com', role='teacher')
                    test_user.set_password('testpassword')
                    db.session.add(test_user)
                    db.session.commit()
                    print("Created test account: test_teacher / testpassword")
                else:
                    print("Test account already exists")
                    
            # Try login with test account
            response = client.post('/login', data={
                'username': 'test_teacher',
                'password': 'testpassword'
            }, follow_redirects=True)
            
            # Check response
            content = response.data.decode('utf-8')
            print(f"\nTest account login:")
            print(f"Status code: {response.status_code}")
            print(f"Login successful: {'Login successful' in content}")
            print(f"Error message: {'Invalid username or password' in content}")

if __name__ == "__main__":
    test_login()