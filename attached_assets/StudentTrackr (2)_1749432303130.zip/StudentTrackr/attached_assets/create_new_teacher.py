from app import app, db
from models import User, Teacher, Class

def create_new_teacher():
    with app.app_context():
        # Check if teacher1 already exists
        if User.query.filter_by(username='teacher1').first():
            print("teacher1 account already exists.")
            return
            
        # Create teacher1 account with password 'password'
        teacher_user = User(username='teacher1', email='teacher1@example.com', role='teacher')
        teacher_user.set_password('password')
        db.session.add(teacher_user)
        db.session.flush()  # To get the user ID
        
        # Create teacher profile
        teacher = Teacher(
            user_id=teacher_user.id,
            first_name='John',
            last_name='Doe',
            subject='Computer Science'
        )
        db.session.add(teacher)
        db.session.commit()
        
        # Verify the teacher was created
        print(f"Created teacher account: username=teacher1, password=password")
        
        # Check if Machine Learning class exists
        ml_class = Class.query.filter_by(name='Machine Learning').first()
        if ml_class:
            # Assign class to this teacher
            ml_class.teacher_id = teacher.id
            db.session.commit()
            print(f"Assigned Machine Learning class to teacher1")

if __name__ == "__main__":
    create_new_teacher()