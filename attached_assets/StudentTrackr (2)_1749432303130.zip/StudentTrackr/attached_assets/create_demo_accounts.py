from app import app, db
from models import User, Teacher, Student, Parent, Class, Attendance
from datetime import datetime, date, timedelta
import random

def create_demo_accounts():
    """Create demo accounts for the application"""
    with app.app_context():
        # Check if demo accounts already exist
        if User.query.filter_by(username='teacher').first():
            print("Demo accounts already exist. Skipping creation.")
            return
        
        print("Creating demo accounts...")
        
        # Create teacher account
        teacher_user = User(username='teacher', email='teacher@example.com', role='teacher')
        teacher_user.set_password('password')
        db.session.add(teacher_user)
        
        teacher = Teacher(
            user=teacher_user,
            first_name='John',
            last_name='Smith',
            subject='Computer Science'
        )
        db.session.add(teacher)
        
        # Create student account
        student_user = User(username='student', email='student@example.com', role='student')
        student_user.set_password('password')
        db.session.add(student_user)
        
        student = Student(
            user=student_user,
            first_name='Jane',
            last_name='Doe',
            roll_number='S001'
        )
        db.session.add(student)
        
        # Create parent account linked to the student
        parent_user = User(username='parent', email='parent@example.com', role='parent')
        parent_user.set_password('password')
        db.session.add(parent_user)
        
        parent = Parent(
            user=parent_user,
            first_name='Robert',
            last_name='Doe',
            phone='555-123-4567',
            student_id=1  # Will be linked to the first student
        )
        db.session.add(parent)
        
        # Create a class
        class_obj = Class(
            name='Introduction to Programming',
            teacher_id=1  # Will be linked to the first teacher
        )
        db.session.add(class_obj)
        
        # Commit to get IDs
        db.session.commit()
        
        # Add student to class
        class_obj.students.append(student)
        
        # Create some attendance records for the past week
        today = date.today()
        for i in range(7):
            record_date = today - timedelta(days=i)
            # Skip weekends
            if record_date.weekday() >= 5:  # 5 = Saturday, 6 = Sunday
                continue
                
            # Randomize attendance status
            status = random.choice(['present', 'present', 'present', 'absent', 'late'])
            
            attendance = Attendance(
                student_id=student.id,
                class_id=class_obj.id,
                date=record_date,
                status=status,
                time_in=datetime.strptime('09:00', '%H:%M').time() if status != 'absent' else None,
                marked_by=teacher.id
            )
            db.session.add(attendance)
        
        db.session.commit()
        print("Demo accounts created successfully.")

if __name__ == "__main__":
    create_demo_accounts()