import os
import logging
from app import app, db
from models import Student
from face_recognition_utils import encode_face

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def add_sample_image_to_student(student_username, image_path):
    """Add a sample image to an existing student"""
    try:
        with app.app_context():
            # Find the student by username
            student = Student.query.join(Student.user).filter_by(username=student_username).first()
            
            if not student:
                logger.error(f"Student with username {student_username} not found")
                return False
                
            # Check if the image exists
            if not os.path.exists(image_path):
                logger.error(f"Image file not found: {image_path}")
                return False
                
            # Encode the face from the image
            face_encoding = encode_face(image_path)
            
            if face_encoding is None:
                logger.error(f"Could not encode face from image: {image_path}")
                return False
                
            # Update the student's face encoding
            student.face_encoding = face_encoding
            db.session.commit()
            
            logger.info(f"Successfully added face encoding for student: {student.first_name} {student.last_name}")
            return True
            
    except Exception as e:
        logger.error(f"Error adding sample image: {str(e)}")
        return False

def add_all_sample_images():
    """Add all sample images to the database"""
    # Map student usernames to sample image paths
    sample_images = {
        'prathyusha_student': 'attached_assets/WhatsApp Image 2025-04-29 at 14.28.09_c4ff8330.jpg',
        'nithin_student': 'attached_assets/WhatsApp Image 2025-04-29 at 14.28.38_b0a09361.jpg',
        'sathwik_student': 'attached_assets/WhatsApp Image 2025-04-29 at 14.29.26_4055679d.jpg'
    }
    
    success_count = 0
    
    for username, image_path in sample_images.items():
        logger.info(f"Processing {username} with image {image_path}...")
        
        if add_sample_image_to_student(username, image_path):
            success_count += 1
            
    logger.info(f"Added {success_count}/{len(sample_images)} sample images successfully")
    
if __name__ == "__main__":
    add_all_sample_images()