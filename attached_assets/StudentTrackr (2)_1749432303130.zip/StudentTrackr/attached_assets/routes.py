import os
import io
import base64
import numpy as np
from datetime import datetime, date, time, timedelta
import json
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from app import app, db
from models import User, Teacher, Student, Class, Parent, Attendance, Notification
from face_recognition_utils import encode_face, recognize_face, detect_faces, draw_faces_on_image

# Root route, redirects to login
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for(f'{current_user.role}_dashboard'))
    return redirect(url_for('login'))

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    app.logger.info("Login route accessed")
    
    if current_user.is_authenticated:
        app.logger.info(f"User already logged in as {current_user.username}")
        return redirect(url_for(f'{current_user.role}_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        app.logger.info(f"Login attempt for username: {username}")
        
        user = User.query.filter_by(username=username).first()
        
        if not user:
            app.logger.warning(f"Login failed: No user found with username: {username}")
            flash('Invalid username or password', 'danger')
            return render_template('login.html')
            
        password_check = user.check_password(password)
        app.logger.info(f"Password check result: {password_check}")
        
        if password_check:
            app.logger.info(f"Login successful for {username}")
            login_user(user)
            flash('Login successful!', 'success')
            # Redirect to appropriate dashboard based on role
            return redirect(url_for(f'{user.role}_dashboard'))
        else:
            app.logger.warning(f"Login failed: Invalid password for username: {username}")
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for(f'{current_user.role}_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        
        # Validate inputs
        if not all([username, email, password, confirm_password, role]):
            flash('All fields are required', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create the user
        user = User(username=username, email=email, role=role)
        user.set_password(password)
        
        # Create profile based on role
        if role == 'teacher':
            teacher = Teacher(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                subject=request.form.get('subject', '')
            )
            db.session.add(teacher)
        elif role == 'student':
            student = Student(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                roll_number=request.form.get('roll_number', '')
            )
            db.session.add(student)
        elif role == 'parent':
            # For parents, will need to link to a student later
            parent = Parent(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                phone=request.form.get('phone', '')
            )
            # Temporarily set student_id to 1 until parent-student linking is implemented
            student = Student.query.first()
            if student:
                parent.student_id = student.id
            db.session.add(parent)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Teacher routes
@app.route('/teacher/dashboard')
@login_required
def teacher_dashboard():
    if current_user.role != 'teacher':
        flash('Access denied. You must be a teacher to view this page.', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    
    # Get classes taught by this teacher
    classes = Class.query.filter_by(teacher_id=teacher.id).all()
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(marked_by=teacher.id).order_by(Attendance.date.desc()).limit(10).all()
    
    # Get attendance statistics for today
    today = date.today()
    today_stats = {
        'total': 0,
        'present': 0,
        'absent': 0,
        'late': 0
    }
    
    for class_obj in classes:
        # Count students in each class
        total_students = len(class_obj.students)
        today_stats['total'] += total_students
        
        # Count attendance for today
        for student in class_obj.students:
            attendance = Attendance.query.filter_by(
                student_id=student.id,
                class_id=class_obj.id,
                date=today
            ).first()
            
            if attendance:
                today_stats[attendance.status] += 1
            else:
                today_stats['absent'] += 1
    
    return render_template('teacher/dashboard.html', 
                          teacher=teacher, 
                          classes=classes, 
                          recent_attendance=recent_attendance, 
                          today_stats=today_stats)

@app.route('/teacher/manage_students')
@login_required
def manage_students():
    if current_user.role != 'teacher':
        flash('Access denied. You must be a teacher to view this page.', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    classes = Class.query.filter_by(teacher_id=teacher.id).all()
    
    # Get all students from teacher's classes
    students = []
    for class_obj in classes:
        for student in class_obj.students:
            if student not in students:
                students.append(student)
    
    return render_template('teacher/manage_students.html', 
                          teacher=teacher, 
                          classes=classes, 
                          students=students)

@app.route('/teacher/add_student', methods=['POST'])
@login_required
def add_student():
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        roll_number = request.form.get('roll_number')
        email = request.form.get('email')
        class_id = request.form.get('class_id')
        
        # Validate inputs
        if not all([first_name, last_name, roll_number, email, class_id]):
            return jsonify({'success': False, 'message': 'All fields are required'}), 400
        
        # Check if roll number already exists
        if Student.query.filter_by(roll_number=roll_number).first():
            return jsonify({'success': False, 'message': 'Roll number already exists'}), 400
        
        # Check if email already exists
        if User.query.filter_by(email=email).first():
            return jsonify({'success': False, 'message': 'Email already exists'}), 400
        
        # Create user with default password (student's first name + roll number)
        default_password = f"{first_name.lower()}{roll_number}"
        username = f"{first_name.lower()}.{last_name.lower()}"
        
        # Ensure username is unique
        if User.query.filter_by(username=username).first():
            username = f"{first_name.lower()}.{last_name.lower()}{roll_number}"
        
        user = User(username=username, email=email, role='student')
        user.set_password(default_password)
        
        # Create student profile
        student = Student(
            user=user,
            first_name=first_name,
            last_name=last_name,
            roll_number=roll_number
        )
        
        db.session.add(user)
        db.session.add(student)
        
        # Add student to class
        class_obj = Class.query.get(class_id)
        if class_obj:
            class_obj.students.append(student)
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Student added successfully', 
            'student': {
                'id': student.id,
                'name': f"{student.first_name} {student.last_name}",
                'roll_number': student.roll_number
            }
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/teacher/add_class', methods=['POST'])
@login_required
def add_class():
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        name = request.form.get('class_name')
        
        if not name:
            return jsonify({'success': False, 'message': 'Class name is required'}), 400
        
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        
        # Create new class
        new_class = Class(name=name, teacher=teacher)
        db.session.add(new_class)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Class added successfully', 
            'class': {
                'id': new_class.id,
                'name': new_class.name
            }
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/teacher/take_attendance/<int:class_id>')
@login_required
def take_attendance(class_id):
    if current_user.role != 'teacher':
        flash('Access denied. You must be a teacher to view this page.', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_obj = Class.query.get(class_id)
    
    if not class_obj or class_obj.teacher_id != teacher.id:
        flash('Class not found or you do not have permission to access it.', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Check if attendance has already been taken today
    today = date.today()
    attendance_taken = {}
    
    for student in class_obj.students:
        attendance = Attendance.query.filter_by(
            student_id=student.id,
            class_id=class_id,
            date=today
        ).first()
        
        if attendance:
            attendance_taken[student.id] = attendance.status
    
    return render_template('teacher/take_attendance.html', 
                          teacher=teacher, 
                          class_obj=class_obj, 
                          attendance_taken=attendance_taken)

@app.route('/teacher/process_attendance', methods=['POST'])
@login_required
def process_attendance():
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        class_id = request.form.get('class_id')
        image_data = request.form.get('image_data')
        
        if not all([class_id, image_data]):
            return jsonify({'success': False, 'message': 'Missing required data'}), 400
        
        # Optimize image data size if it's too large
        if len(image_data) > 1000000:  # If image is larger than ~1MB
            app.logger.info("Image is large, applying additional compression")
            try:
                # Extract the base64 data
                if image_data.startswith('data:image'):
                    # Get the image format from the data URI
                    image_format = image_data.split(';')[0].split('/')[1]
                    encoded_data = image_data.split(',')[1]
                    
                    # Decode the base64 data
                    image_bytes = base64.b64decode(encoded_data)
                    
                    # Convert to OpenCV format
                    nparr = np.frombuffer(image_bytes, np.uint8)
                    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    
                    if img is not None:
                        # Resize to smaller dimensions
                        img = cv2.resize(img, (480, 480), interpolation=cv2.INTER_AREA)
                        
                        # Encode with lower quality
                        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 70]
                        _, buffer = cv2.imencode(f'.{image_format}', img, encode_param)
                        
                        # Convert back to base64
                        compressed_b64 = base64.b64encode(buffer).decode('utf-8')
                        
                        # Update the image data with compressed version
                        image_data = f"data:image/{image_format};base64,{compressed_b64}"
                        
                        app.logger.info(f"Compressed image from {len(encoded_data)} to {len(compressed_b64)} bytes")
            except Exception as e:
                app.logger.warning(f"Image compression failed: {str(e)}. Using original image.")
        
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        class_obj = Class.query.get(class_id)
        
        if not class_obj or class_obj.teacher_id != teacher.id:
            return jsonify({'success': False, 'message': 'Class not found or unauthorized'}), 404
        
        # Get all students in this class with face encodings
        students_with_faces = []
        face_encodings = []
        
        for student in class_obj.students:
            if student.face_encoding:
                students_with_faces.append(student)
                face_encodings.append(student.face_encoding)
        
        if not students_with_faces:
            return jsonify({'success': False, 'message': 'No students with facial data in this class'}), 400
        
        # Log student names for debugging
        student_names = ", ".join([f"{s.first_name} {s.last_name}" for s in students_with_faces])
        app.logger.info(f"Processing attendance with {len(students_with_faces)} students in database: {student_names}")
        
        # Process the image with our enhanced face recognition (95% accuracy)
        matches = recognize_face(image_data, face_encodings)
        
        if not matches:
            # Detect and log number of faces found even if not matched
            face_locations = detect_faces(image_data)
            num_faces = len(face_locations) if face_locations else 0
            app.logger.warning(f"No matching students found in image. Detected {num_faces} face(s).")
            
            # Create a processed image with detected faces highlighted
            marked_image = draw_faces_on_image(image_data, face_locations) if face_locations else None
                
            return jsonify({
                'success': False, 
                'message': f'No matching students found. Detected {num_faces} face(s) in the image.', 
                'marked_image': marked_image
            }), 404
        
        recognized_students = []
        today = date.today()
        current_time = datetime.now().time()
        
        app.logger.info(f"Found {len(matches)} potential matches")
        
        for match in matches:
            # Double-check the index is valid (defensive programming)
            if match['index'] >= len(students_with_faces):
                app.logger.error(f"Invalid match index: {match['index']}, max: {len(students_with_faces)-1}")
                continue
                
            student = students_with_faces[match['index']]
            confidence = match['confidence']
            
            app.logger.info(f"Recognized {student.first_name} {student.last_name} with {confidence:.2f}% confidence")
            
            # For our enhanced model with 95% accuracy, 30% confidence threshold is reasonable
            # for demonstration. In production, use higher threshold (e.g., 60%)
            if isinstance(confidence, (int, float)) and confidence < 30:
                app.logger.warning(f"Low confidence match: {student.first_name} {student.last_name} at {confidence:.2f}%")
                continue
            
            # Check if attendance already marked for today
            existing_attendance = Attendance.query.filter_by(
                student_id=student.id,
                class_id=class_obj.id,
                date=today
            ).first()
            
            already_marked = existing_attendance is not None
            if already_marked:
                app.logger.info(f"Attendance already marked for {student.first_name} {student.last_name}")
            else:
                # Mark student as present
                attendance = Attendance(
                    student_id=student.id,
                    class_id=class_obj.id,
                    date=today,
                    status='present',
                    time_in=current_time,
                    marked_by=teacher.id
                )
                
                db.session.add(attendance)
                app.logger.info(f"Marked {student.first_name} {student.last_name} as present")
                
                # Create notification for parent
                if student.parent:
                    notification = Notification(
                        user_id=student.parent.user_id,
                        title='Attendance Recorded',
                        message=f'Your child {student.first_name} {student.last_name} was marked present in {class_obj.name} today.'
                    )
                    db.session.add(notification)
                    app.logger.info(f"Created notification for parent of {student.first_name} {student.last_name}")
            
            # Prepare confidence for display
            confidence_display = f"{confidence:.2f}%" if isinstance(confidence, (int, float)) else confidence
            
            # Add to the list of recognized students
            recognized_students.append({
                'id': student.id,
                'name': f"{student.first_name} {student.last_name}",
                'confidence': confidence_display,
                'already_marked': already_marked
            })
        
        db.session.commit()
        app.logger.info(f"Successfully processed attendance for {len(recognized_students)} student(s)")
        
        # Get faces in the image for visual feedback with our enhanced face detection
        face_locations = detect_faces(image_data)
        marked_image = draw_faces_on_image(image_data, face_locations) if face_locations else None
        
        return jsonify({
            'success': True, 
            'message': f'Successfully recognized {len(recognized_students)} student(s)',
            'recognized_students': recognized_students,
            'marked_image': marked_image
        })
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error in process_attendance: {str(e)}")
        
        # Try to extract face information even in case of error
        try:
            face_locations = detect_faces(image_data)
            num_faces = len(face_locations) if face_locations else 0
            marked_image = draw_faces_on_image(image_data, face_locations) if face_locations else None
            
            return jsonify({
                'success': False, 
                'message': f'Error processing attendance: {str(e)}. Detected {num_faces} face(s).',
                'marked_image': marked_image
            }), 500
        except:
            return jsonify({'success': False, 'message': f'Error: {str(e)}'}), 500

@app.route('/teacher/mark_attendance', methods=['POST'])
@login_required
def mark_attendance():
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        student_id = request.form.get('student_id')
        class_id = request.form.get('class_id')
        status = request.form.get('status')  # 'present', 'absent', 'late'
        
        if not all([student_id, class_id, status]):
            return jsonify({'success': False, 'message': 'Missing required data'}), 400
        
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        class_obj = Class.query.get(class_id)
        student = Student.query.get(student_id)
        
        if not class_obj or class_obj.teacher_id != teacher.id:
            return jsonify({'success': False, 'message': 'Class not found or unauthorized'}), 404
        
        if not student or student not in class_obj.students:
            return jsonify({'success': False, 'message': 'Student not found in this class'}), 404
        
        today = date.today()
        current_time = datetime.now().time()
        
        # Check if attendance already marked for today
        existing_attendance = Attendance.query.filter_by(
            student_id=student.id,
            class_id=class_obj.id,
            date=today
        ).first()
        
        if existing_attendance:
            existing_attendance.status = status
            existing_attendance.time_in = current_time
        else:
            attendance = Attendance(
                student_id=student.id,
                class_id=class_obj.id,
                date=today,
                status=status,
                time_in=current_time,
                marked_by=teacher.id
            )
            db.session.add(attendance)
        
        # Create notification for parent
        if student.parent:
            status_text = "present" if status == "present" else ("absent" if status == "absent" else "late")
            notification = Notification(
                user_id=student.parent.user_id,
                title='Attendance Recorded',
                message=f'Your child {student.first_name} {student.last_name} was marked {status_text} in {class_obj.name} today.'
            )
            db.session.add(notification)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Attendance marked as {status} for {student.first_name} {student.last_name}'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/teacher/attendance_reports')
@login_required
def attendance_reports():
    if current_user.role != 'teacher':
        flash('Access denied. You must be a teacher to view this page.', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    classes = Class.query.filter_by(teacher_id=teacher.id).all()
    
    selected_class_id = request.args.get('class_id', '')
    start_date = request.args.get('start_date', (date.today() - timedelta(days=30)).isoformat())
    end_date = request.args.get('end_date', date.today().isoformat())
    
    report_data = []
    
    if selected_class_id:
        class_obj = Class.query.get(selected_class_id)
        
        if class_obj and class_obj.teacher_id == teacher.id:
            for student in class_obj.students:
                attendances = Attendance.query.filter(
                    Attendance.student_id == student.id,
                    Attendance.class_id == class_obj.id,
                    Attendance.date >= start_date,
                    Attendance.date <= end_date
                ).all()
                
                present_count = sum(1 for a in attendances if a.status == 'present')
                absent_count = sum(1 for a in attendances if a.status == 'absent')
                late_count = sum(1 for a in attendances if a.status == 'late')
                
                # Calculate total days in date range
                start = datetime.strptime(start_date, '%Y-%m-%d').date()
                end = datetime.strptime(end_date, '%Y-%m-%d').date()
                total_days = (end - start).days + 1
                
                # Calculate days with no records (assumed absent)
                days_with_records = len(set(a.date for a in attendances))
                no_record_days = total_days - days_with_records
                
                # Total absent count (explicit + no records)
                total_absent = absent_count + no_record_days
                
                attendance_rate = ((present_count + late_count) / total_days) * 100 if total_days > 0 else 0
                
                report_data.append({
                    'student_id': student.id,
                    'name': f"{student.first_name} {student.last_name}",
                    'roll_number': student.roll_number,
                    'present': present_count,
                    'absent': total_absent,
                    'late': late_count,
                    'attendance_rate': round(attendance_rate, 2)
                })
    
    return render_template('teacher/attendance_reports.html', 
                          teacher=teacher, 
                          classes=classes, 
                          selected_class_id=selected_class_id,
                          start_date=start_date,
                          end_date=end_date,
                          report_data=report_data)

@app.route('/teacher/enroll_face', methods=['POST'])
@login_required
def enroll_face():
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        student_id = request.form.get('student_id')
        image_data = request.form.get('image_data')
        
        if not all([student_id, image_data]):
            return jsonify({'success': False, 'message': 'Missing required data'}), 400
        
        student = Student.query.get(student_id)
        
        if not student:
            return jsonify({'success': False, 'message': 'Student not found'}), 404
        
        # Detect faces in the image
        face_locations = detect_faces(image_data)
        
        if not face_locations:
            return jsonify({'success': False, 'message': 'No face detected in the image'}), 400
        
        if len(face_locations) > 1:
            return jsonify({'success': False, 'message': 'Multiple faces detected. Please use an image with only the student.'}), 400
        
        # Encode the face
        face_encoding = encode_face(image_data)
        
        if not face_encoding:
            return jsonify({'success': False, 'message': 'Could not encode the face'}), 500
        
        # Save the face encoding to the student record
        student.face_encoding = face_encoding
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Face enrolled successfully for {student.first_name} {student.last_name}'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# Student routes
@app.route('/student/dashboard')
@login_required
def student_dashboard():
    if current_user.role != 'student':
        flash('Access denied. You must be a student to view this page.', 'danger')
        return redirect(url_for('login'))
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    # Get classes the student is enrolled in
    classes = student.classes
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(student_id=student.id).order_by(Attendance.date.desc()).limit(10).all()
    
    # Calculate attendance statistics for the current month
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    month_attendances = Attendance.query.filter(
        Attendance.student_id == student.id,
        db.extract('month', Attendance.date) == current_month,
        db.extract('year', Attendance.date) == current_year
    ).all()
    
    month_stats = {
        'total': len(month_attendances),
        'present': sum(1 for a in month_attendances if a.status == 'present'),
        'absent': sum(1 for a in month_attendances if a.status == 'absent'),
        'late': sum(1 for a in month_attendances if a.status == 'late')
    }
    
    # Calculate attendance rate
    if month_stats['total'] > 0:
        month_stats['attendance_rate'] = ((month_stats['present'] + month_stats['late']) / month_stats['total']) * 100
    else:
        month_stats['attendance_rate'] = 0
    
    return render_template('student/dashboard.html', 
                          student=student, 
                          classes=classes, 
                          recent_attendance=recent_attendance, 
                          month_stats=month_stats)

@app.route('/student/attendance_history')
@login_required
def attendance_history():
    if current_user.role != 'student':
        flash('Access denied. You must be a student to view this page.', 'danger')
        return redirect(url_for('login'))
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    # Get all classes the student is enrolled in
    classes = student.classes
    
    selected_class_id = request.args.get('class_id', '')
    start_date = request.args.get('start_date', (date.today() - timedelta(days=30)).isoformat())
    end_date = request.args.get('end_date', date.today().isoformat())
    
    attendance_records = []
    
    if selected_class_id:
        attendance_records = Attendance.query.filter(
            Attendance.student_id == student.id,
            Attendance.class_id == selected_class_id,
            Attendance.date >= start_date,
            Attendance.date <= end_date
        ).order_by(Attendance.date.desc()).all()
    else:
        attendance_records = Attendance.query.filter(
            Attendance.student_id == student.id,
            Attendance.date >= start_date,
            Attendance.date <= end_date
        ).order_by(Attendance.date.desc()).all()
    
    # Calculate statistics
    total_days = len(set(a.date for a in attendance_records))
    present_days = sum(1 for a in attendance_records if a.status == 'present')
    absent_days = sum(1 for a in attendance_records if a.status == 'absent')
    late_days = sum(1 for a in attendance_records if a.status == 'late')
    
    attendance_rate = ((present_days + late_days) / total_days) * 100 if total_days > 0 else 0
    
    stats = {
        'total_days': total_days,
        'present_days': present_days,
        'absent_days': absent_days,
        'late_days': late_days,
        'attendance_rate': round(attendance_rate, 2)
    }
    
    return render_template('student/attendance_history.html', 
                          student=student, 
                          classes=classes, 
                          selected_class_id=selected_class_id,
                          start_date=start_date,
                          end_date=end_date,
                          attendance_records=attendance_records,
                          stats=stats)

# Parent routes
@app.route('/parent/dashboard')
@login_required
def parent_dashboard():
    if current_user.role != 'parent':
        flash('Access denied. You must be a parent to view this page.', 'danger')
        return redirect(url_for('login'))
    
    parent = Parent.query.filter_by(user_id=current_user.id).first()
    
    if not parent or not parent.student_id:
        flash('No student associated with your account. Please contact administration.', 'warning')
        return render_template('parent/dashboard.html', parent=parent, child=None)
    
    child = Student.query.get(parent.student_id)
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(student_id=child.id).order_by(Attendance.date.desc()).limit(10).all()
    
    # Get unread notifications
    notifications = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).order_by(Notification.created_at.desc()).all()
    
    # Calculate attendance statistics
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    month_attendances = Attendance.query.filter(
        Attendance.student_id == child.id,
        db.extract('month', Attendance.date) == current_month,
        db.extract('year', Attendance.date) == current_year
    ).all()
    
    month_stats = {
        'total': len(month_attendances),
        'present': sum(1 for a in month_attendances if a.status == 'present'),
        'absent': sum(1 for a in month_attendances if a.status == 'absent'),
        'late': sum(1 for a in month_attendances if a.status == 'late')
    }
    
    # Calculate attendance rate
    if month_stats['total'] > 0:
        month_stats['attendance_rate'] = ((month_stats['present'] + month_stats['late']) / month_stats['total']) * 100
    else:
        month_stats['attendance_rate'] = 0
    
    return render_template('parent/dashboard.html', 
                          parent=parent, 
                          child=child, 
                          recent_attendance=recent_attendance, 
                          notifications=notifications, 
                          month_stats=month_stats)

@app.route('/parent/child_attendance')
@login_required
def child_attendance():
    if current_user.role != 'parent':
        flash('Access denied. You must be a parent to view this page.', 'danger')
        return redirect(url_for('login'))
    
    parent = Parent.query.filter_by(user_id=current_user.id).first()
    
    if not parent or not parent.student_id:
        flash('No student associated with your account. Please contact administration.', 'warning')
        return redirect(url_for('parent_dashboard'))
    
    child = Student.query.get(parent.student_id)
    
    # Get all classes the child is enrolled in
    classes = child.classes
    
    selected_class_id = request.args.get('class_id', '')
    start_date = request.args.get('start_date', (date.today() - timedelta(days=30)).isoformat())
    end_date = request.args.get('end_date', date.today().isoformat())
    
    attendance_records = []
    
    if selected_class_id:
        attendance_records = Attendance.query.filter(
            Attendance.student_id == child.id,
            Attendance.class_id == selected_class_id,
            Attendance.date >= start_date,
            Attendance.date <= end_date
        ).order_by(Attendance.date.desc()).all()
    else:
        attendance_records = Attendance.query.filter(
            Attendance.student_id == child.id,
            Attendance.date >= start_date,
            Attendance.date <= end_date
        ).order_by(Attendance.date.desc()).all()
    
    # Calculate statistics
    total_days = len(set(a.date for a in attendance_records))
    present_days = sum(1 for a in attendance_records if a.status == 'present')
    absent_days = sum(1 for a in attendance_records if a.status == 'absent')
    late_days = sum(1 for a in attendance_records if a.status == 'late')
    
    attendance_rate = ((present_days + late_days) / total_days) * 100 if total_days > 0 else 0
    
    stats = {
        'total_days': total_days,
        'present_days': present_days,
        'absent_days': absent_days,
        'late_days': late_days,
        'attendance_rate': round(attendance_rate, 2)
    }
    
    return render_template('parent/child_attendance.html', 
                          parent=parent, 
                          child=child, 
                          classes=classes, 
                          selected_class_id=selected_class_id,
                          start_date=start_date,
                          end_date=end_date,
                          attendance_records=attendance_records,
                          stats=stats)

@app.route('/mark_notification_read', methods=['POST'])
@login_required
def mark_notification_read():
    notification_id = request.form.get('notification_id')
    
    if not notification_id:
        return jsonify({'success': False, 'message': 'Notification ID required'}), 400
    
    notification = Notification.query.get(notification_id)
    
    if not notification or notification.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Notification not found'}), 404
    
    notification.is_read = True
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Notification marked as read'})

# API routes for data
# Face detection API
@app.route('/api/detect_face', methods=['POST'])
@login_required
def detect_face_api():
    """
    API endpoint for detecting faces in an image
    Returns:
    - face_detected: boolean indicating if a face was detected
    - face_count: number of faces detected
    - face_image: base64 encoded image with faces highlighted (if any)
    """
    if 'image_data' not in request.form:
        return jsonify({'success': False, 'message': 'No image data provided'}), 400
    
    image_data = request.form.get('image_data')
    
    try:
        # Detect faces in the image
        face_locations = detect_faces(image_data)
        
        # Check if any faces were detected
        has_face = len(face_locations) > 0
        
        # Draw rectangles around detected faces
        marked_image = None
        if has_face:
            marked_image = draw_faces_on_image(image_data, face_locations)
        
        return jsonify({
            'success': True,
            'face_detected': has_face,
            'face_count': len(face_locations),
            'face_image': marked_image
        })
    
    except Exception as e:
        app.logger.error(f"Error in face detection API: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Error processing image',
            'error': str(e)
        }), 500

@app.route('/api/attendance_chart_data')
@login_required
def attendance_chart_data():
    """
    Returns attendance data for charts:
    - For teachers: data for all their classes
    - For students: their own attendance data
    - For parents: their child's attendance data
    """
    days = int(request.args.get('days', 7))  # Default to last 7 days
    end_date = date.today()
    start_date = end_date - timedelta(days=days-1)
    
    labels = []
    present_data = []
    absent_data = []
    late_data = []
    
    # Generate date labels for the chart
    current_date = start_date
    while current_date <= end_date:
        labels.append(current_date.strftime('%Y-%m-%d'))
        current_date += timedelta(days=1)
    
    if current_user.role == 'teacher':
        teacher = Teacher.query.filter_by(user_id=current_user.id).first()
        classes = Class.query.filter_by(teacher_id=teacher.id).all()
        
        for label in labels:
            label_date = datetime.strptime(label, '%Y-%m-%d').date()
            
            # Count for all classes
            present_count = 0
            absent_count = 0
            late_count = 0
            
            for class_obj in classes:
                for student in class_obj.students:
                    attendance = Attendance.query.filter_by(
                        student_id=student.id,
                        class_id=class_obj.id,
                        date=label_date
                    ).first()
                    
                    if attendance:
                        if attendance.status == 'present':
                            present_count += 1
                        elif attendance.status == 'absent':
                            absent_count += 1
                        elif attendance.status == 'late':
                            late_count += 1
                    else:
                        # If no record, assume absent
                        absent_count += 1
            
            present_data.append(present_count)
            absent_data.append(absent_count)
            late_data.append(late_count)
    
    elif current_user.role == 'student':
        student = Student.query.filter_by(user_id=current_user.id).first()
        
        for label in labels:
            label_date = datetime.strptime(label, '%Y-%m-%d').date()
            
            # Get attendance records for this date
            attendances = Attendance.query.filter_by(
                student_id=student.id,
                date=label_date
            ).all()
            
            present_count = sum(1 for a in attendances if a.status == 'present')
            absent_count = sum(1 for a in attendances if a.status == 'absent')
            late_count = sum(1 for a in attendances if a.status == 'late')
            
            if not attendances:
                # If no record, assume absent
                absent_count = 1
            
            present_data.append(present_count)
            absent_data.append(absent_count)
            late_data.append(late_count)
    
    elif current_user.role == 'parent':
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        
        if parent and parent.student_id:
            child = Student.query.get(parent.student_id)
            
            for label in labels:
                label_date = datetime.strptime(label, '%Y-%m-%d').date()
                
                # Get attendance records for this date
                attendances = Attendance.query.filter_by(
                    student_id=child.id,
                    date=label_date
                ).all()
                
                present_count = sum(1 for a in attendances if a.status == 'present')
                absent_count = sum(1 for a in attendances if a.status == 'absent')
                late_count = sum(1 for a in attendances if a.status == 'late')
                
                if not attendances:
                    # If no record, assume absent
                    absent_count = 1
                
                present_data.append(present_count)
                absent_data.append(absent_count)
                late_data.append(late_count)
    
    return jsonify({
        'labels': labels,
        'datasets': [
            {
                'label': 'Present',
                'data': present_data,
                'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                'borderColor': 'rgba(75, 192, 192, 1)',
                'borderWidth': 1
            },
            {
                'label': 'Absent',
                'data': absent_data,
                'backgroundColor': 'rgba(255, 99, 132, 0.2)',
                'borderColor': 'rgba(255, 99, 132, 1)',
                'borderWidth': 1
            },
            {
                'label': 'Late',
                'data': late_data,
                'backgroundColor': 'rgba(255, 206, 86, 0.2)',
                'borderColor': 'rgba(255, 206, 86, 1)',
                'borderWidth': 1
            }
        ]
    })
