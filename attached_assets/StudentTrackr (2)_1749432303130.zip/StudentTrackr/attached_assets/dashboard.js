/**
 * Dashboard utilities and charts
 */
document.addEventListener('DOMContentLoaded', function() {
    // Create attendance chart
    const attendanceChartCanvas = document.getElementById('attendanceChart');
    if (attendanceChartCanvas) {
        const ctx = attendanceChartCanvas.getContext('2d');
        
        // Get chart data from the data-chart attribute
        const chartData = JSON.parse(attendanceChartCanvas.dataset.chart || '{}');
        
        if (chartData && chartData.labels && chartData.datasets) {
            new Chart(ctx, {
                type: 'bar',
                data: chartData,
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Count'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Date'
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        },
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Attendance History'
                        }
                    }
                }
            });
        }
    }
    
    // Create attendance rate chart
    const attendanceRateCanvas = document.getElementById('attendanceRateChart');
    if (attendanceRateCanvas) {
        const ctx = attendanceRateCanvas.getContext('2d');
        
        // Get chart data from the data-chart attribute
        const chartData = JSON.parse(attendanceRateCanvas.dataset.chart || '{}');
        
        if (chartData && chartData.labels && chartData.datasets) {
            new Chart(ctx, {
                type: 'pie',
                data: chartData,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Attendance Distribution'
                        }
                    }
                }
            });
        }
    }
    
    // Handle add student modal
    const addStudentForm = document.getElementById('addStudentForm');
    if (addStudentForm) {
        addStudentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(addStudentForm);
            
            fetch('/teacher/add_student', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Reload the page to show the new student
                    window.location.reload();
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error adding student:', error);
                alert('Error adding student. Please try again.');
            });
        });
    }
    
    // Handle add class modal
    const addClassForm = document.getElementById('addClassForm');
    if (addClassForm) {
        addClassForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(addClassForm);
            
            fetch('/teacher/add_class', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Reload the page to show the new class
                    window.location.reload();
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error adding class:', error);
                alert('Error adding class. Please try again.');
            });
        });
    }
});
