"""
Mock face_recognition module for development when the real face_recognition library is not available
Enhanced with more realistic and consistent face recognition behavior - 95% accuracy
"""
import numpy as np
import logging
import os

logger = logging.getLogger(__name__)
logger.warning("Using mock face_recognition module. Face recognition functionality will be simulated.")

# Maintain a cache of fake encodings to ensure consistency
_mock_encoding_cache = {}

def face_locations(image):
    """
    Mock implementation that returns a simulated face location
    Now with more realistic detection based on image dimensions
    """
    # Return a simulated face location (top, right, bottom, left)
    height, width = image.shape[:2]
    
    # Simulate face detection in center of image (more realistic than random)
    face_size = min(height, width) // 3
    top = (height - face_size) // 2
    left = (width - face_size) // 2
    bottom = top + face_size
    right = left + face_size
    
    # Implement 95% accuracy
    if np.random.random() < 0.95:
        logger.debug("Mock face_locations: detected a face")
        return [(top, right, bottom, left)]
    else:
        logger.debug("Mock face_locations: simulating no face detected")
        return []

def face_encodings(image, known_face_locations=None):
    """
    Mock implementation that returns a consistent face encoding for the same image
    Uses image hash as a seed for reproducible results
    """
    # If no face locations provided or empty list, return empty list
    if not known_face_locations:
        return []
    
    # Generate a simple hash of the image for consistent encodings
    # Take samples from the image to create a fingerprint
    h, w = image.shape[:2]
    samples = [
        str(image[h//4, w//4].sum()),
        str(image[h//4, 3*w//4].sum()),
        str(image[3*h//4, w//4].sum()),
        str(image[3*h//4, 3*w//4].sum()),
        str(image[h//2, w//2].sum())
    ]
    image_hash = "_".join(samples)
    
    # Use the cache for consistent encoding or generate a new one
    if image_hash in _mock_encoding_cache:
        logger.debug(f"Using cached encoding for image hash")
        return [_mock_encoding_cache[image_hash]]
    
    # Generate a deterministic encoding based on the image hash
    # This ensures the same image gets the same encoding
    # Seed the random generator with hash value for determinism
    seed = sum(ord(c) for c in image_hash) % (2**32 - 1)  # Ensure within numpy's seed range
    np.random.seed(seed)
    
    # Generate encoding and cache it
    encoding = np.random.rand(128)
    # Normalize the encoding (typical for face recognition vectors)
    encoding = encoding / np.linalg.norm(encoding)
    _mock_encoding_cache[image_hash] = encoding
    
    logger.debug(f"Generated new encoding for image")
    return [encoding]

def face_distance(face_encodings, face_to_compare):
    """
    Mock implementation for face distance calculation - 95% accuracy
    Provides realistic distances with higher match probability for sample images
    """
    # If no face encodings, return empty list
    if not face_encodings:
        return []
    
    # Get the filename if it's in the list of known student images
    sample_img_indicators = ["whatsapp", "student", "face", "prathyusha", "nithin", "sathwik"]
    
    # Check if we're comparing against a well-known training image
    compare_str = str(face_to_compare)
    is_sample_image = any(indicator.lower() in compare_str.lower() for indicator in sample_img_indicators)
    
    distances = []
    for i, encoding in enumerate(face_encodings):
        # For demonstration with 95% accuracy 
        if np.random.random() < 0.95:
            # Good match - 95% of the time
            distances.append(0.3 + np.random.random() * 0.25)  # Range 0.3-0.55
        else:
            # Poor match - 5% of the time (simulating errors)
            distances.append(0.6 + np.random.random() * 0.3)   # Range 0.6-0.9
    
    return distances