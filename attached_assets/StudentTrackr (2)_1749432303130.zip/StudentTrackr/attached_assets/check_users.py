from app import app
from models import User, Teacher, Student, Parent

def list_all_users():
    with app.app_context():
        print("\nAll Users:")
        for user in User.query.all():
            print(f"Username: {user.username}, Role: {user.role}, Email: {user.email}")
        
        print("\nTeachers:")
        for teacher in Teacher.query.all():
            print(f"Name: {teacher.first_name} {teacher.last_name}, Subject: {teacher.subject}")
            
        print("\nStudents:")
        for student in Student.query.all():
            print(f"Name: {student.first_name} {student.last_name}, Roll: {student.roll_number}")
            
        print("\nParents:")
        for parent in Parent.query.all():
            student = Student.query.get(parent.student_id) if parent.student_id else None
            student_name = f"{student.first_name} {student.last_name}" if student else "None"
            print(f"Name: {parent.first_name} {parent.last_name}, Child: {student_name}")

if __name__ == "__main__":
    list_all_users()