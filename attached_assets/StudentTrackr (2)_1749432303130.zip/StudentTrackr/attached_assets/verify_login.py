from app import app, db
from models import User
import werkzeug.security

def check_passwords():
    with app.app_context():
        # Get all users
        users = User.query.all()
        
        print("User Authentication Test\n")
        print("=" * 50)
        
        for user in users:
            # Extract the hashed password
            print(f"Username: {user.username}")
            print(f"Role: {user.role}")
            print(f"Password hash: {user.password_hash}")
            
            # Test with a known password "password"
            result = werkzeug.security.check_password_hash(user.password_hash, "password")
            print(f"Password verification ('password'): {result}")
            
            # Display the hashing method
            if user.password_hash and user.password_hash.startswith('pbkdf2:sha256:'):
                print("Hashing algorithm: pbkdf2:sha256")
            elif user.password_hash and user.password_hash.startswith('scrypt:'):
                print("Hashing algorithm: scrypt")
            else:
                print(f"Unknown hashing algorithm: {user.password_hash[:10] if user.password_hash else 'None'}...")
                
            print("-" * 50)
            
        # Create a test user with a known password
        test_user = User(username="test_login", email="test@example.com", role="teacher")
        test_user.set_password("password")
        
        print("\nTest user created:")
        print(f"Username: {test_user.username}")
        print(f"Password hash: {test_user.password_hash}")
        
        # Verify the password setting and checking works
        print(f"Password verification ('password'): {test_user.check_password('password')}")
        print(f"Password verification ('wrong'): {test_user.check_password('wrong')}")
        
        # Verify using werkzeug directly
        print(f"Direct werkzeug verification ('password'): {werkzeug.security.check_password_hash(test_user.password_hash, 'password')}")
        
        # We won't save this test user to the database

if __name__ == "__main__":
    check_passwords()