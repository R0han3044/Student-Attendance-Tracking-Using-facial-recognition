/**
 * Handle attendance taking in the classroom
 */
document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const imageUploadForm = document.getElementById('image-upload-form');
    const resultContainer = document.getElementById('recognition-result');
    const processedImageContainer = document.getElementById('processed-image');
    const manualAttendanceForm = document.getElementById('manual-attendance-form');
    const attendanceImageInput = document.getElementById('attendance-image');
    const imagePreview = document.getElementById('image-preview');
    const previewImg = document.getElementById('preview-img');
    
    // Preview image when selected
    if (attendanceImageInput) {
        attendanceImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    imagePreview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                imagePreview.style.display = 'none';
            }
        });
    }
    
    // Process image and mark attendance
    if (imageUploadForm) {
        imageUploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const file = attendanceImageInput.files[0];
            if (!file) {
                alert('Please select an image file.');
                return;
            }
            
            const classId = document.getElementById('class-id').value;
            if (!classId) {
                alert('Class ID is missing.');
                return;
            }
            
            // Show a loading state
            resultContainer.innerHTML = '<div class="alert alert-info">Processing image...</div>';
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const imageData = e.target.result;
                
                // Send to server for processing
                fetch('/teacher/process_attendance', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        'class_id': classId,
                        'image_data': imageData
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show processed image
                        if (data.processed_image) {
                            processedImageContainer.innerHTML = `<img src="${data.processed_image}" alt="Processed Image" class="img-fluid">`;
                        }
                        
                        // Show recognized students
                        if (data.recognized_students && data.recognized_students.length > 0) {
                            let studentsList = '<div class="alert alert-success"><h5>Recognized Students:</h5><ul>';
                            data.recognized_students.forEach(student => {
                                studentsList += `<li>${student.name} - ${student.status}${student.already_marked ? ' (already marked)' : ''}</li>`;
                            });
                            studentsList += '</ul></div>';
                            resultContainer.innerHTML = studentsList;
                        } else {
                            resultContainer.innerHTML = '<div class="alert alert-warning">No students recognized.</div>';
                        }
                    } else {
                        resultContainer.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                    }
                })
                .catch(error => {
                    console.error('Error processing attendance:', error);
                    resultContainer.innerHTML = '<div class="alert alert-danger">Error processing attendance. Please try again.</div>';
                });
            };
            
            reader.readAsDataURL(file);
        });
    }
    
    // Handle manual attendance marking
    if (manualAttendanceForm) {
        manualAttendanceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const studentId = document.getElementById('student-id').value;
            const classId = document.getElementById('class-id').value;
            const status = document.getElementById('status').value;
            
            fetch('/teacher/mark_attendance_manually', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'student_id': studentId,
                    'class_id': classId,
                    'status': status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Optionally refresh the page
                    window.location.reload();
                } else {
                    alert(`Error: ${data.message}`);
                }
            })
            .catch(error => {
                console.error('Error marking attendance:', error);
                alert('Error marking attendance. Please try again.');
            });
        });
    }
});