from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, FileField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[('teacher', 'Teacher'), ('student', 'Student'), ('parent', 'Parent')])
    
    # Common fields
    first_name = StringField('First Name', validators=[DataRequired()])
    last_name = StringField('Last Name', validators=[DataRequired()])
    
    # Teacher specific fields
    subject = StringField('Subject')
    
    # Student specific fields
    roll_number = StringField('Roll Number')
    
    # Parent specific fields
    phone = StringField('Phone Number')
    student_roll_number = StringField('Student Roll Number')
    
    submit = SubmitField('Register')

class AddStudentForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired()])
    last_name = StringField('Last Name', validators=[DataRequired()])
    roll_number = StringField('Roll Number', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    class_id = SelectField('Class', coerce=int, validators=[DataRequired()])
    face_image = FileField('Face Image')
    submit = SubmitField('Add Student')

class AddClassForm(FlaskForm):
    name = StringField('Class Name', validators=[DataRequired()])
    submit = SubmitField('Add Class')
