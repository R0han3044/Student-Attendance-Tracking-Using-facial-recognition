import os
import base64
from datetime import datetime
from werkzeug.security import generate_password_hash
from app import app, db
from models import User, Student, Class, Teacher
import face_recognition_utils

def create_teacher_if_not_exists():
    """Create a teacher if none exists"""
    teacher = Teacher.query.first()
    if teacher:
        print(f"Teacher already exists: {teacher.first_name} {teacher.last_name}")
        return teacher
    
    # Create user for teacher
    teacher_user = User(
        username='teacher1',
        email='teacher1@example.com',
        role='teacher',
        created_at=datetime.utcnow()
    )
    teacher_user.set_password('password')
    db.session.add(teacher_user)
    db.session.flush()  # Get the user ID
    
    # Create teacher profile
    teacher = Teacher(
        user_id=teacher_user.id,
        first_name='Demo',
        last_name='Teacher',
        subject='Computer Science'
    )
    db.session.add(teacher)
    db.session.commit()
    print(f"Created teacher: Demo Teacher")
    return teacher

def create_class_if_not_exists(teacher_id):
    """Create a class if none exists"""
    class_obj = Class.query.first()
    if class_obj:
        print(f"Class already exists: {class_obj.name}")
        return class_obj
    
    # Create class
    class_obj = Class(
        name='Machine Learning',
        teacher_id=teacher_id
    )
    db.session.add(class_obj)
    db.session.commit()
    print(f"Created class: Machine Learning")
    return class_obj

def add_student(username, email, password, first_name, last_name, roll_number, image_path):
    """Add a student to the database with face encoding from the given image"""
    
    # Check if student already exists
    existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
    if existing_user:
        print(f"User with username {username} or email {email} already exists")
        return None
    
    # Create user for student
    user = User(
        username=username,
        email=email,
        role='student',
        created_at=datetime.utcnow()
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()  # Get the user ID
    
    # Process the face image
    face_encoding = None
    if image_path and os.path.exists(image_path):
        try:
            # Read the image file
            with open(image_path, 'rb') as f:
                image_data = f.read()
                # Store the raw image data for face encoding
                face_encoding = image_data
        except Exception as e:
            print(f"Error processing image: {str(e)}")
    
    # Create student profile
    student = Student(
        user_id=user.id,
        first_name=first_name,
        last_name=last_name,
        roll_number=roll_number,
        face_encoding=face_encoding
    )
    db.session.add(student)
    db.session.commit()
    print(f"Added student: {first_name} {last_name}")
    return student

if __name__ == "__main__":
    with app.app_context():
        # Ensure we have a teacher
        teacher = create_teacher_if_not_exists()
        
        # Ensure we have a class
        class_obj = create_class_if_not_exists(teacher.id)
        
        # Add Nithin
        nithin = add_student(
            username='nithin',
            email='nithin@example.com',
            password='password',
            first_name='Nithin',
            last_name='Naik',
            roll_number='STU001',
            image_path='static/student_images/nithin.jpg'
        )
        
        # Add Sathwik
        sathwik = add_student(
            username='sathwik',
            email='sathwik@example.com',
            password='password',
            first_name='Sathwik',
            last_name='Reddy',
            roll_number='STU002',
            image_path='static/student_images/sathwik.jpg'
        )
        
        # Add Prathyusha
        prathyusha = add_student(
            username='prathyusha',
            email='prathyusha@example.com',
            password='password',
            first_name='Prathyusha',
            last_name='Mudhiraj',
            roll_number='STU003',
            image_path='static/student_images/prathyusha.jpg'
        )
        
        # Enroll students in the class
        students = [nithin, sathwik, prathyusha]
        for student in students:
            if student and student not in class_obj.students:
                class_obj.students.append(student)
                print(f"Enrolled {student.first_name} {student.last_name} in {class_obj.name} class")
        
        db.session.commit()
        print("All students added and enrolled successfully!")