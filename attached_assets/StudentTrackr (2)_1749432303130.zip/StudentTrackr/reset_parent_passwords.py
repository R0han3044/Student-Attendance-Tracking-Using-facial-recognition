"""
Script to reset parent passwords to a known value for testing
"""
import logging
from app import app, db
from models import User, Parent, Student

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def reset_parent_passwords():
    """Reset parent passwords to a known value for testing"""
    with app.app_context():
        parent_users = User.query.filter_by(role='parent').all()
        
        if not parent_users:
            logger.warning("No parent accounts found in the database.")
            return
        
        logger.info(f"Found {len(parent_users)} parent accounts to reset passwords for")
        
        # Standard password for testing
        standard_password = "Parent123!"
        
        # Information to display
        login_info = []
        
        for user in parent_users:
            # Reset password
            user.set_password(standard_password)
            
            # Get parent details
            parent = Parent.query.filter_by(user_id=user.id).first()
            if parent:
                student = Student.query.get(parent.student_id)
                login_info.append({
                    'username': user.username,
                    'password': standard_password,
                    'parent_name': f"{parent.first_name} {parent.last_name}",
                    'student_name': f"{student.first_name} {student.last_name}" if student else "Unknown"
                })
            
        # Commit the changes
        db.session.commit()
        logger.info("Parent passwords have been reset")
        
        # Display login information
        print("\n=== PARENT LOGIN INFORMATION ===")
        print("Password for all parent accounts: " + standard_password)
        print("\nParent Accounts:")
        for info in login_info:
            print(f"  • {info['parent_name']} (parent of {info['student_name']}):")
            print(f"    - Username: {info['username']}")
        
        logger.info("Parent login information displayed")

if __name__ == "__main__":
    reset_parent_passwords()
    logger.info("Script completed successfully")