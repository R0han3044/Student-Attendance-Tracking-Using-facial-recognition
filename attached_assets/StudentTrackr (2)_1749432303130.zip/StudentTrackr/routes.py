import os
import io
import base64
import numpy as np
from datetime import datetime, date, time, timedelta
import json
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from app import app, db
from models import User, Teacher, Student, Class, Parent, Attendance, Notification
from face_recognition_utils import encode_face, recognize_face, detect_faces, draw_faces_on_image

# Add a custom function to Jinja environment for getting the current datetime
@app.context_processor
def utility_processor():
    return {
        'now': datetime.now
    }

# Root route, redirects to login
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for(f'{current_user.role}_dashboard'))
    return redirect(url_for('login'))

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    app.logger.info("Login route accessed")
    
    if current_user.is_authenticated:
        app.logger.info(f"User already logged in as {current_user.username}")
        return redirect(url_for(f'{current_user.role}_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        app.logger.info(f"Login attempt for username: {username}")
        
        user = User.query.filter_by(username=username).first()
        
        if not user:
            app.logger.warning(f"Login failed: No user found with username: {username}")
            flash('Invalid username or password', 'danger')
            return render_template('login.html')
            
        password_check = user.check_password(password)
        app.logger.info(f"Password check result: {password_check}")
        
        if password_check:
            app.logger.info(f"Login successful for {username}")
            login_user(user)
            flash('Login successful!', 'success')
            # Redirect to appropriate dashboard based on role
            return redirect(url_for(f'{user.role}_dashboard'))
        else:
            app.logger.warning(f"Login failed: Invalid password for username: {username}")
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for(f'{current_user.role}_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = request.form.get('role')
        
        # Validate inputs
        if not all([username, email, password, confirm_password, role]):
            flash('All fields are required', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create the user
        user = User(username=username, email=email, role=role)
        user.set_password(password)
        
        # Create profile based on role
        if role == 'teacher':
            teacher = Teacher(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                subject=request.form.get('subject', '')
            )
            db.session.add(teacher)
        elif role == 'student':
            student = Student(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                roll_number=request.form.get('roll_number', '')
            )
            db.session.add(student)
        elif role == 'parent':
            # For parents, will need to link to a student
            student_roll = request.form.get('student_roll_number', '')
            student = Student.query.filter_by(roll_number=student_roll).first()
            
            if not student:
                flash('Student with given roll number not found', 'danger')
                return render_template('register.html')
                
            parent = Parent(
                user=user,
                first_name=request.form.get('first_name', ''),
                last_name=request.form.get('last_name', ''),
                phone=request.form.get('phone', ''),
                student_id=student.id
            )
            db.session.add(parent)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# Teacher routes
@app.route('/teacher/dashboard')
@login_required
def teacher_dashboard():
    if current_user.role != 'teacher':
        flash('Access denied. You must be a teacher to view this page.', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    
    # Get classes taught by this teacher
    classes = Class.query.filter_by(teacher_id=teacher.id).all()
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(marked_by=teacher.id).order_by(Attendance.date.desc()).limit(10).all()
    
    # Get attendance statistics for today
    today = date.today()
    today_stats = {
        'total': 0,
        'present': 0,
        'absent': 0,
        'late': 0
    }
    
    for class_obj in classes:
        # Count students in each class
        total_students = len(class_obj.students)
        today_stats['total'] += total_students
        
        # Count attendance for today
        for student in class_obj.students:
            attendance = Attendance.query.filter_by(
                student_id=student.id,
                class_id=class_obj.id,
                date=today
            ).first()
            
            if attendance:
                today_stats[attendance.status] += 1
            else:
                today_stats['absent'] += 1
    
    return render_template('teacher/dashboard.html', 
                          teacher=teacher, 
                          classes=classes, 
                          recent_attendance=recent_attendance, 
                          today_stats=today_stats)

@app.route('/teacher/add_class', methods=['POST'])
@login_required
def add_class():
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_name = request.form.get('class_name')
    
    if not class_name:
        flash('Class name is required', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Create new class
    new_class = Class(
        name=class_name,
        teacher_id=teacher.id
    )
    
    db.session.add(new_class)
    db.session.commit()
    
    flash(f'Class "{class_name}" has been created successfully', 'success')
    return redirect(url_for('teacher_dashboard'))

@app.route('/teacher/add_student', methods=['POST'])
@login_required
def add_student():
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    # Get form data
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    roll_number = request.form.get('roll_number')
    email = request.form.get('email')
    class_id = request.form.get('class_id')
    
    # Validate data
    if not all([first_name, last_name, roll_number, email, class_id]):
        flash('All fields are required', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Check if email or roll number already exists
    if User.query.filter_by(email=email).first():
        flash('Email already exists', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    if Student.query.filter_by(roll_number=roll_number).first():
        flash('Roll number already exists', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Generate username and password
    username = f"{first_name.lower()}.{last_name.lower()}"
    count = 1
    while User.query.filter_by(username=username).first():
        username = f"{first_name.lower()}.{last_name.lower()}{count}"
        count += 1
    
    password = f"{first_name.lower()}{roll_number}"
    
    # Create user
    user = User(
        username=username,
        email=email,
        role='student'
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()  # To get the user ID
    
    # Create student
    student = Student(
        user_id=user.id,
        first_name=first_name,
        last_name=last_name,
        roll_number=roll_number
    )
    db.session.add(student)
    
    # Add student to class
    class_obj = Class.query.get(class_id)
    if class_obj:
        class_obj.students.append(student)
    
    db.session.commit()
    
    flash(f'Student {first_name} {last_name} has been added successfully', 'success')
    return redirect(url_for('teacher_dashboard'))

@app.route('/teacher/take_attendance/<int:class_id>')
@login_required
def take_attendance(class_id):
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_obj = Class.query.get_or_404(class_id)
    
    # Check if teacher is authorized for this class
    if class_obj.teacher_id != teacher.id:
        flash('You are not authorized to take attendance for this class', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Get today's attendance records
    today = date.today()
    today_attendance = {}
    
    for student in class_obj.students:
        attendance = Attendance.query.filter_by(
            student_id=student.id,
            class_id=class_id,
            date=today
        ).first()
        
        if attendance:
            today_attendance[student.id] = attendance
    
    return render_template('teacher/take_attendance.html',
                          teacher=teacher,
                          class_obj=class_obj,
                          today_attendance=today_attendance)

@app.route('/teacher/process_attendance/<int:class_id>', methods=['POST'])
@login_required
def process_attendance_image(class_id):
    if current_user.role != 'teacher':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_obj = Class.query.get_or_404(class_id)
    
    # Check if teacher is authorized for this class
    if class_obj.teacher_id != teacher.id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    # Get image data from request
    if 'attendance_image' in request.files:
        # Handle file upload
        file = request.files['attendance_image']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No image file provided'}), 400
        
        # Read the image file
        image_data = file.read()
    elif request.is_json and 'image_data' in request.json:
        # Handle base64 image data
        image_data = request.json['image_data']
    else:
        return jsonify({'success': False, 'message': 'No image data provided'}), 400
    
    # Get all students in the class with their face encodings
    students_with_face = []
    for student in class_obj.students:
        if student.face_encoding:
            students_with_face.append({
                'id': student.id,
                'name': f"{student.first_name} {student.last_name}",
                'roll_number': student.roll_number,
                'face_encoding': student.face_encoding
            })
    
    if not students_with_face:
        return jsonify({'success': False, 'message': 'No students with face encodings found in this class'}), 404
    
    # Perform face recognition
    known_face_encodings = [student['face_encoding'] for student in students_with_face]
    matches = recognize_face(image_data, known_face_encodings)
    
    # Process recognition results and mark attendance
    recognized_students = []
    today = date.today()
    current_time = datetime.now().time()
    
    for match in matches:
        match_index = match.get('match_index')
        confidence = match.get('confidence', 0)
        
        if match_index is not None and 0 <= match_index < len(students_with_face):
            student = students_with_face[match_index]
            student_id = student['id']
            
            # Check if attendance already marked
            existing_attendance = Attendance.query.filter_by(
                student_id=student_id,
                class_id=class_id,
                date=today
            ).first()
            
            already_marked = existing_attendance is not None
            
            # Determine status based on time (example: late after 9:00 AM)
            late_threshold = time(9, 0)  # 9:00 AM
            status = 'present'
            if current_time > late_threshold:
                status = 'late'
            
            # Only create new attendance record if not already marked
            if not already_marked:
                attendance = Attendance(
                    student_id=student_id,
                    class_id=class_id,
                    date=today,
                    time_in=current_time,
                    status=status,
                    marked_by=teacher.id,
                    method='face_recognition'
                )
                db.session.add(attendance)
            
            recognized_students.append({
                'id': student_id,
                'name': student['name'],
                'roll_number': student['roll_number'],
                'confidence': confidence,
                'status': status,
                'already_marked': already_marked
            })
    
    # Commit changes to database
    if recognized_students:
        db.session.commit()
    
    # Process image with face boxes if available
    processed_image = None
    face_locations, _ = detect_faces(image_data)
    if face_locations:
        processed_image = draw_faces_on_image(image_data, face_locations)
    
    return jsonify({
        'success': True,
        'recognized_students': recognized_students,
        'processed_image': processed_image
    })

@app.route('/teacher/upload_attendance_photo/<int:class_id>', methods=['GET', 'POST'])
@login_required
def upload_attendance_photo(class_id):
    """
    New route for uploading attendance photos directly instead of using webcam
    """
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_obj = Class.query.get_or_404(class_id)
    
    # Check if teacher is authorized for this class
    if class_obj.teacher_id != teacher.id:
        flash('You are not authorized to take attendance for this class', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Get today's attendance records
    today = date.today()
    today_attendance = {}
    
    for student in class_obj.students:
        attendance = Attendance.query.filter_by(
            student_id=student.id,
            class_id=class_id,
            date=today
        ).first()
        
        if attendance:
            today_attendance[student.id] = attendance
    
    if request.method == 'POST':
        # Check if there's an uploaded file
        if 'attendance_photo' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        
        file = request.files['attendance_photo']
        
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        
        # Validate file is an image
        if not file or not file.filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            flash('Invalid file format. Please upload a JPG or PNG image.', 'danger')
            return redirect(request.url)
        
        try:
            # Read the image file
            image_data = file.read()
            
            # Get all students in the class with their face encodings
            students_with_face = []
            for student in class_obj.students:
                if student.face_encoding:
                    students_with_face.append({
                        'id': student.id,
                        'name': f"{student.first_name} {student.last_name}",
                        'roll_number': student.roll_number,
                        'face_encoding': student.face_encoding
                    })
            
            if not students_with_face:
                flash('No students with face encodings found in this class', 'warning')
                return redirect(request.url)
            
            # Perform face recognition
            known_face_encodings = [student['face_encoding'] for student in students_with_face]
            matches = recognize_face(image_data, known_face_encodings)
            
            # Process recognition results and mark attendance
            recognized_students = []
            current_time = datetime.now().time()
            
            for match in matches:
                match_index = match.get('match_index')
                confidence = match.get('confidence', 0)
                
                if match_index is not None and 0 <= match_index < len(students_with_face):
                    student = students_with_face[match_index]
                    student_id = student['id']
                    
                    # Check if attendance already marked
                    existing_attendance = Attendance.query.filter_by(
                        student_id=student_id,
                        class_id=class_id,
                        date=today
                    ).first()
                    
                    already_marked = existing_attendance is not None
                    
                    # Determine status based on time (example: late after 9:00 AM)
                    late_threshold = time(9, 0)  # 9:00 AM
                    status = 'present'
                    if current_time > late_threshold:
                        status = 'late'
                    
                    # Only create new attendance record if not already marked
                    if not already_marked:
                        attendance = Attendance(
                            student_id=student_id,
                            class_id=class_id,
                            date=today,
                            time_in=current_time,
                            status=status,
                            marked_by=teacher.id,
                            method='photo_upload'
                        )
                        db.session.add(attendance)
                    
                    recognized_students.append({
                        'name': student['name'],
                        'roll_number': student['roll_number'],
                        'confidence': confidence,
                        'status': status if not already_marked else 'already marked'
                    })
            
            # Commit changes to database
            if recognized_students:
                db.session.commit()
                flash(f"Successfully marked attendance for {len(recognized_students)} students from photo", 'success')
            else:
                flash("No students were recognized in the uploaded photo", 'warning')
                
            # Return to the attendance page with updated records
            return redirect(url_for('take_attendance', class_id=class_id))
            
        except Exception as e:
            app.logger.error(f"Error processing uploaded attendance photo: {str(e)}")
            flash('Error processing photo. Please try again.', 'danger')
            return redirect(request.url)
    
    return render_template('teacher/upload_attendance_photo.html',
                          teacher=teacher,
                          class_obj=class_obj,
                          today_attendance=today_attendance)

@app.route('/teacher/mark_manual_attendance/<int:class_id>', methods=['POST'])
@login_required
def mark_manual_attendance(class_id):
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('login'))
    
    teacher = Teacher.query.filter_by(user_id=current_user.id).first()
    class_obj = Class.query.get_or_404(class_id)
    
    # Check if teacher is authorized for this class
    if class_obj.teacher_id != teacher.id:
        flash('You are not authorized to take attendance for this class', 'danger')
        return redirect(url_for('teacher_dashboard'))
    
    # Get form data
    student_id = request.form.get('student_id')
    status = request.form.get('status')
    notes = request.form.get('notes', '')
    
    # Validate data
    if not all([student_id, status]):
        flash('Student and status are required', 'danger')
        return redirect(url_for('take_attendance', class_id=class_id))
    
    # Check if student exists and belongs to this class
    student = Student.query.get(student_id)
    if not student or student not in class_obj.students:
        flash('Invalid student selected', 'danger')
        return redirect(url_for('take_attendance', class_id=class_id))
    
    # Check if attendance already marked for today
    today = date.today()
    existing_attendance = Attendance.query.filter_by(
        student_id=student_id,
        class_id=class_id,
        date=today
    ).first()
    
    if existing_attendance:
        # Update existing attendance
        existing_attendance.status = status
        existing_attendance.notes = notes
        existing_attendance.marked_by = teacher.id
        existing_attendance.method = 'manual'
        if status != 'absent':
            existing_attendance.time_in = datetime.now().time()
    else:
        # Create new attendance record
        attendance = Attendance(
            student_id=student_id,
            class_id=class_id,
            date=today,
            time_in=datetime.now().time() if status != 'absent' else None,
            status=status,
            marked_by=teacher.id,
            method='manual',
            notes=notes
        )
        db.session.add(attendance)
    
    db.session.commit()
    
    flash(f'Attendance marked as {status} for {student.first_name} {student.last_name}', 'success')
    return redirect(url_for('take_attendance', class_id=class_id))

@app.route('/student/dashboard')
@login_required
def student_dashboard():
    if current_user.role != 'student':
        flash('Access denied. You must be a student to view this page.', 'danger')
        return redirect(url_for('login'))
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    # Get classes this student is enrolled in
    classes = student.classes
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(student_id=student.id).order_by(Attendance.date.desc()).limit(5).all()
    
    # Calculate attendance stats for each class
    attendance_stats = {}
    
    for class_obj in classes:
        # Get all attendance records for this class
        records = Attendance.query.filter_by(
            student_id=student.id,
            class_id=class_obj.id
        ).all()
        
        total = len(records)
        present = sum(1 for r in records if r.status == 'present')
        late = sum(1 for r in records if r.status == 'late')
        absent = sum(1 for r in records if r.status == 'absent')
        
        attendance_rate = 0
        if total > 0:
            attendance_rate = round(((present + late) / total) * 100, 1)
        
        attendance_stats[class_obj.id] = {
            'total': total,
            'present': present,
            'late': late,
            'absent': absent,
            'attendance_rate': attendance_rate
        }
    
    return render_template('student/dashboard.html',
                          student=student,
                          classes=classes,
                          recent_attendance=recent_attendance,
                          attendance_stats=attendance_stats)

@app.route('/upload_face', methods=['GET', 'POST'])
@login_required
def upload_face():
    if current_user.role != 'student':
        flash('Access denied. Only students can upload face images.', 'danger')
        return redirect(url_for('index'))
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'face_image' not in request.files:
            if request.is_json:
                # Handle AJAX request with base64 data
                data = request.json
                if 'image_data' not in data:
                    return jsonify({'success': False, 'message': 'No image data provided'}), 400
                
                image_data = data['image_data']
            else:
                flash('No image file uploaded', 'danger')
                return redirect(request.url)
        else:
            # Handle traditional form upload
            file = request.files['face_image']
            if file.filename == '':
                flash('No image selected', 'danger')
                return redirect(request.url)
            
            # Read the image file
            image_data = file.read()
        
        # Process the image and extract face encoding
        try:
            face_encoding = encode_face(image_data)
            
            if face_encoding is None:
                if request.is_json:
                    return jsonify({'success': False, 'message': 'No face detected in the image'}), 400
                flash('No face detected in the image. Please try again with a clearer photo.', 'danger')
                return redirect(request.url)
            
            # Save the face encoding to the student record
            student.face_encoding = face_encoding
            db.session.commit()
            
            if request.is_json:
                return jsonify({'success': True, 'message': 'Face image uploaded successfully'})
            
            flash('Face image uploaded successfully!', 'success')
            return redirect(url_for('student_dashboard'))
            
        except Exception as e:
            app.logger.error(f"Error processing face image: {str(e)}")
            if request.is_json:
                return jsonify({'success': False, 'message': 'Error processing image'}), 500
            flash('Error processing image. Please try again.', 'danger')
            return redirect(request.url)
    
    return render_template('upload_face.html', student=student)

@app.route('/parent/dashboard')
@login_required
def parent_dashboard():
    if current_user.role != 'parent':
        flash('Access denied. You must be a parent to view this page.', 'danger')
        return redirect(url_for('login'))
    
    parent = Parent.query.filter_by(user_id=current_user.id).first()
    
    if not parent:
        flash('Parent profile not found.', 'danger')
        return redirect(url_for('logout'))
    
    # Get the student linked to this parent
    student = Student.query.get(parent.student_id)
    
    if not student:
        flash('No student linked to this parent account.', 'warning')
        return render_template('parent/dashboard.html', parent=parent, notifications=[])
    
    # Get recent attendance records
    recent_attendance = Attendance.query.filter_by(student_id=student.id).order_by(Attendance.date.desc()).limit(10).all()
    
    # Calculate overall attendance stats
    all_records = Attendance.query.filter_by(student_id=student.id).all()
    total = len(all_records)
    present = sum(1 for r in all_records if r.status == 'present')
    late = sum(1 for r in all_records if r.status == 'late')
    absent = sum(1 for r in all_records if r.status == 'absent')
    
    attendance_rate = 0
    if total > 0:
        attendance_rate = round(((present + late) / total) * 100, 1)
    
    attendance_stats = {
        'present': present,
        'late': late,
        'absent': absent,
        'total': total,
        'attendance_rate': attendance_rate
    }
    
    # Get notifications
    notifications = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(5).all()
    
    # Create a demo notification if none exist
    if not notifications and student:
        demo_notification = Notification(
            user_id=current_user.id,
            title=f'Welcome to Parent Dashboard',
            message=f'You can track your child\'s attendance and receive real-time notifications here.',
            is_read=False,
            created_at=datetime.utcnow()
        )
        db.session.add(demo_notification)
        db.session.commit()
        notifications = [demo_notification]
    
    return render_template('parent/dashboard.html',
                          parent=parent,
                          student=student,
                          recent_attendance=recent_attendance,
                          attendance_stats=attendance_stats,
                          notifications=notifications)

# Route to mark notifications as read
@app.route('/parent/mark_notification_read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    if current_user.role != 'parent':
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    notification = Notification.query.get(notification_id)
    if not notification or notification.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Notification not found'}), 404
    
    notification.is_read = True
    db.session.commit()
    
    return jsonify({'success': True})

# Accessibility Statement
@app.route('/accessibility')
def accessibility_statement():
    return render_template('accessibility_statement.html')

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, error_message="Page not found"), 404

@app.errorhandler(403)
def forbidden(e):
    return render_template('error.html', error_code=403, error_message="Access forbidden"), 403

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html', error_code=500, error_message="Internal server error"), 500