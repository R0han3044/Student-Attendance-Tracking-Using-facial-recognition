"""
Enhanced face recognition model with improved accuracy and confidence
"""
import cv2
import numpy as np
from app import app, db
from models import Student
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_enhanced_face_encoding(face_image):
    """
    Create an enhanced face encoding with multiple feature extraction methods
    for higher accuracy and confidence
    """
    try:
        # Convert to grayscale if needed
        if len(face_image.shape) == 3:
            gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
        else:
            gray = face_image
        
        # Resize to consistent size for better comparison
        resized = cv2.resize(gray, (128, 128))
        
        # Apply advanced preprocessing
        # 1. Histogram equalization for better contrast
        equalized = cv2.equalizeHist(resized)
        
        # 2. Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(equalized, (3, 3), 0)
        
        # 3. Extract multiple types of features
        features = []
        
        # Statistical features
        features.extend([
            np.mean(blurred),
            np.std(blurred),
            np.median(blurred),
            np.min(blurred),
            np.max(blurred),
            np.var(blurred)
        ])
        
        # Gradient features (edge information)
        grad_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(grad_x**2 + grad_y**2)
        
        features.extend([
            np.mean(gradient_magnitude),
            np.std(gradient_magnitude),
            np.max(gradient_magnitude),
            np.mean(grad_x),
            np.std(grad_x),
            np.mean(grad_y),
            np.std(grad_y)
        ])
        
        # LBP (Local Binary Pattern) features for texture
        lbp = compute_lbp(blurred)
        lbp_hist, _ = np.histogram(lbp.ravel(), bins=256, range=(0, 256))
        lbp_hist = lbp_hist.astype(float)
        lbp_hist /= (lbp_hist.sum() + 1e-7)  # Normalize
        
        # Add top LBP histogram values
        features.extend(lbp_hist[:50].tolist())
        
        # HOG (Histogram of Oriented Gradients) features
        hog_features = compute_hog_features(blurred)
        features.extend(hog_features)
        
        # Facial region analysis (eyes, nose, mouth areas)
        region_features = extract_facial_region_features(blurred)
        features.extend(region_features)
        
        # Convert to numpy array and normalize
        feature_array = np.array(features, dtype=np.float64)
        
        # Normalize features to [0, 1] range for better comparison
        feature_array = (feature_array - np.min(feature_array)) / (np.max(feature_array) - np.min(feature_array) + 1e-7)
        
        return feature_array.tobytes()
        
    except Exception as e:
        logger.error(f"Error creating enhanced face encoding: {e}")
        return None

def compute_lbp(image):
    """Compute Local Binary Pattern"""
    rows, cols = image.shape
    lbp = np.zeros((rows-2, cols-2), dtype=np.uint8)
    
    for i in range(1, rows-1):
        for j in range(1, cols-1):
            center = image[i, j]
            binary_string = ""
            
            # 8-neighbor LBP
            neighbors = [
                image[i-1, j-1], image[i-1, j], image[i-1, j+1],
                image[i, j+1], image[i+1, j+1], image[i+1, j],
                image[i+1, j-1], image[i, j-1]
            ]
            
            for neighbor in neighbors:
                binary_string += '1' if neighbor >= center else '0'
            
            lbp[i-1, j-1] = int(binary_string, 2)
    
    return lbp

def compute_hog_features(image):
    """Compute HOG (Histogram of Oriented Gradients) features"""
    # Compute gradients
    grad_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    
    # Compute magnitude and angle
    magnitude = np.sqrt(grad_x**2 + grad_y**2)
    angle = np.arctan2(grad_y, grad_x)
    
    # Convert angle to degrees and make positive
    angle = np.degrees(angle) % 180
    
    # Create histogram of gradients
    hist, _ = np.histogram(angle.ravel(), bins=18, range=(0, 180), weights=magnitude.ravel())
    
    # Normalize
    hist = hist.astype(float)
    hist /= (np.sum(hist) + 1e-7)
    
    return hist.tolist()

def extract_facial_region_features(image):
    """Extract features from specific facial regions"""
    h, w = image.shape
    
    # Define facial regions (approximate)
    # Eyes region (upper third)
    eyes_region = image[:h//3, :]
    
    # Nose region (middle third)
    nose_region = image[h//3:2*h//3, w//4:3*w//4]
    
    # Mouth region (lower third)
    mouth_region = image[2*h//3:, w//4:3*w//4]
    
    features = []
    
    for region in [eyes_region, nose_region, mouth_region]:
        if region.size > 0:
            features.extend([
                np.mean(region),
                np.std(region),
                np.median(region)
            ])
        else:
            features.extend([0, 0, 0])
    
    return features

def retrain_all_students():
    """Retrain all student face encodings with enhanced algorithm"""
    with app.app_context():
        students = Student.query.all()
        logger.info(f"Retraining {len(students)} student face encodings")
        
        updated_count = 0
        
        for i, student in enumerate(students):
            # Load the corresponding extracted face image
            face_filename = f"student_face_{i+1}.jpg"
            
            try:
                # Load the face image
                face_image = cv2.imread(face_filename)
                
                if face_image is not None:
                    # Create enhanced encoding
                    enhanced_encoding = create_enhanced_face_encoding(face_image)
                    
                    if enhanced_encoding:
                        # Update student's face encoding
                        student.face_encoding = enhanced_encoding
                        updated_count += 1
                        logger.info(f"Updated encoding for {student.first_name} {student.last_name}")
                    else:
                        logger.warning(f"Failed to create enhanced encoding for {student.first_name} {student.last_name}")
                else:
                    logger.warning(f"Could not load face image for {student.first_name} {student.last_name}")
                    
            except Exception as e:
                logger.error(f"Error processing {student.first_name} {student.last_name}: {e}")
        
        # Commit all changes
        db.session.commit()
        logger.info(f"Successfully updated {updated_count} student face encodings")
        
        return updated_count

def update_recognition_parameters():
    """Update face recognition parameters for higher confidence"""
    # This will be used to adjust the tolerance in the recognition function
    return {
        'tolerance': 0.8,  # Higher threshold for stricter matching
        'min_confidence': 0.85,  # Minimum confidence required
        'use_enhanced_features': True
    }

if __name__ == "__main__":
    # Retrain all student face encodings
    updated = retrain_all_students()
    print(f"Enhanced face recognition model trained with {updated} students")
    print("Model now configured for higher accuracy and confidence")