"""
Script to fix the Machine Learning class issues by ensuring students are in the correct class
"""
from app import app, db
from models import Class, Student, Teacher, User

def fix_ml_classes():
    """Fix the Machine Learning class issues"""
    # Get all ML classes
    ml_classes = Class.query.filter(Class.name.ilike('%Machine Learning%')).all()
    
    print(f"Found {len(ml_classes)} Machine Learning classes:")
    for cls in ml_classes:
        teacher = Teacher.query.get(cls.teacher_id)
        teacher_user = User.query.get(teacher.user_id)
        print(f"  Class ID: {cls.id}, Name: {cls.name}, Teacher: {teacher.first_name} {teacher.last_name} ({teacher_user.username})")
        print(f"  Students: {len(cls.students)}")
        for student in cls.students:
            print(f"    - {student.first_name} {student.last_name} (Roll #: {student.roll_number})")
    
    # Get all students
    students = Student.query.all()
    print(f"\nFound {len(students)} students in the database.")
    
    # Get the ML class associated with teacher1 (ID 1)
    teacher1_ml_class = Class.query.filter_by(name="Machine Learning", teacher_id=1).first()
    
    if not teacher1_ml_class:
        print("Error: Could not find Machine Learning class for teacher1.")
        return
    
    print(f"\nEnsuring all students are added to the ML class (ID: {teacher1_ml_class.id})...")
    
    # Add all students to teacher1's ML class
    for student in students:
        if student not in teacher1_ml_class.students:
            teacher1_ml_class.students.append(student)
            print(f"  Added {student.first_name} {student.last_name} to the ML class")
        else:
            print(f"  {student.first_name} {student.last_name} is already in the ML class")
    
    db.session.commit()
    print("\nAll students have been added to the correct Machine Learning class!")

if __name__ == "__main__":
    with app.app_context():
        fix_ml_classes()