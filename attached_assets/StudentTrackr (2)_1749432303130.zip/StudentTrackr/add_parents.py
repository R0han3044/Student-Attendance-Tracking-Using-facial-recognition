"""
Script to add parents for students and link them to their children
"""
import logging
from app import app, db
from models import User, Student, Parent
from werkzeug.security import generate_password_hash
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Parent information
PARENTS = [
    {
        "username": "sathwik.parent",
        "email": "sathwik.parent@example.com",
        "password": "pass123",
        "first_name": "Rajesh",
        "last_name": "Reddy",
        "phone": "9876543210",
        "student_username": "sathwik.reddy.2023"
    },
    {
        "username": "nithin.parent",
        "email": "nithin.parent@example.com",
        "password": "pass123",
        "first_name": "Mohan",
        "last_name": "Naik",
        "phone": "9876543211",
        "student_username": "nithin.naik"
    },
    {
        "username": "prathyusha.parent",
        "email": "prathyusha.parent@example.com",
        "password": "pass123",
        "first_name": "Lakshmi",
        "last_name": "Mudhiraj",
        "phone": "9876543212",
        "student_username": "prathyusha.mudhiraj"
    }
]

def add_parent(username, email, password, first_name, last_name, phone, student_username):
    """Add a parent to the database and link to their child"""
    with app.app_context():
        # Check if parent already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            logger.info(f"Parent {username} already exists, skipping")
            return existing_user.parent_profile
        
        # Find the student by username
        student_user = User.query.filter_by(username=student_username).first()
        if not student_user or not student_user.student_profile:
            logger.error(f"Student {student_username} not found, cannot add parent")
            return None
        
        student = student_user.student_profile
        logger.info(f"Adding parent: {first_name} {last_name} for student {student.first_name} {student.last_name}")
        
        # Create user
        user = User(
            username=username,
            email=email,
            role='parent',
            created_at=datetime.utcnow()
        )
        user.set_password(password)
        db.session.add(user)
        db.session.flush()
        
        # Create parent profile
        parent = Parent(
            user_id=user.id,
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            student_id=student.id
        )
        
        db.session.add(parent)
        db.session.commit()
        logger.info(f"Successfully added parent: {first_name} {last_name} for {student.first_name} {student.last_name}")
        return parent

def add_all_parents():
    """Add all parents to the database"""
    for parent_data in PARENTS:
        add_parent(
            username=parent_data["username"],
            email=parent_data["email"],
            password=parent_data["password"],
            first_name=parent_data["first_name"],
            last_name=parent_data["last_name"],
            phone=parent_data["phone"],
            student_username=parent_data["student_username"]
        )

if __name__ == "__main__":
    # Add all parents
    add_all_parents()
    
    logger.info("Script completed successfully")