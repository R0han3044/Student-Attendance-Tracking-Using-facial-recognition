"""
Script to check students in the Machine Learning class
"""
from app import app, db
from models import Class, Student

def check_ml_class():
    """Check students in the Machine Learning class"""
    ml_class = Class.query.filter_by(name="Machine Learning").first()
    
    if not ml_class:
        print("Machine Learning class does not exist.")
        return
    
    print(f"Class: {ml_class.name}")
    print(f"Description: {ml_class.description}")
    print(f"Teacher: {ml_class.teacher.first_name} {ml_class.teacher.last_name}")
    print(f"Number of enrolled students: {len(ml_class.students)}")
    print("\nEnrolled Students:")
    
    for i, student in enumerate(ml_class.students, 1):
        print(f"{i}. {student.first_name} {student.last_name} (Roll #: {student.roll_number})")
        print(f"   Username: {student.user.username}")
        print(f"   Email: {student.user.email}")
        print(f"   Face encoding: {'Available' if student.face_encoding else 'Not available'}")
        print()

if __name__ == "__main__":
    with app.app_context():
        check_ml_class()